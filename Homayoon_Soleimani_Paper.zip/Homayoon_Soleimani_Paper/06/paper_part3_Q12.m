A = [0 1 0 0;
     18.8936 -10.3111 0 70.6712;
     0 0 0 1;
     -2.1282 2.7197 0 -19.4162];
B = [0;-6.5684; 0; 1.7316];
C = [1 0 0 0;
    0 1 0 0;
    0 0 1 0;
    0 0 0 1];
D = 0;
sys = ss(A,B,C,D);
time_vector = 0 :0.001: 5;
initial_condition = [ 0.005 0.1 0 0 ];
Q = eye(4)*10 ;

for i = 10.^(0:3)
    R = eye(1)* i ;
    K = lqr(A,B,Q,R);
    A_closed = A - B*K;
    sys_closed = ss( A_closed, B, C, D);
    input_signal = zeros(length(time_vector), size(B,2));
    [Y_r ,T, X_r] = lsim ( sys_closed,input_signal , time_vector ,initial_condition );
    figure
    subplot(5,1,1);
    plot(time_vector , X_r(: , 1 )) ;
    title('تتا ') ;
    subplot(5,1,2) ;
    plot( time_vector , X_r( : , 2)) ;
    title( 'تتا دات ') ;
    subplot (5,1,3) ;
    plot(time_vector , X_r ( :,3) ) ;
    title("X");
    subplot(5,1,4);
    plot( time_vector , X_r(:,4) ) ;
    title("Xdot ");
    subplot(5,1,5);
    U = -K*X_r';
    plot ( time_vector ,U )
    title("سیگنال کنترل")
    sgtitle ( [ ' R=' , num2str(R) ] );
    
    saveas(gcf, ['figure_R_', num2str(i), '.png']);
    caption = ['تغییر متغیرهای سیستم و ورودی با تغییر ماتریس R=', num2str(i)];
    disp(['Figure saved as figure_R_', num2str(i), '.png with caption: ', caption]);
end

R = eye(1)*1;
for j = 10.^(0:3)
    Q = eye (4)* j;
    K = lqr (A ,B, Q, R);
    A_closed = A - B*K ;
    sys_closed = ss (A_closed , B , C ,D);
    input_signal = zeros(length(time_vector), size(B,2));
    [Y_r, T , X_r ] = lsim (sys_closed ,input_signal , time_vector ,initial_condition );
    figure;
    subplot(5,1,1);
    plot( time_vector ,X_r(: ,1) ) ;
    title( "تتا");
    subplot(5,1,2);
    plot( time_vector , X_r(:,2) ) ;
    title( "تتادوت");
    subplot(5,1,3);
    plot ( time_vector,X_r(:,3) ) ;
    title ( "X");
    subplot(5,1,4) ;
    plot( time_vector ,X_r(: ,4 ) );
    title( "X دات ") ;
    subplot (5,1,5) ;
    U = -K*X_r';
    plot(time_vector, U) ;
    title("ورودی کنترلی ") ;
    sgtitle ( [ " Q =", num2str(j) ] );
    
    saveas(gcf, ['figure_Q_', num2str(j), '.png']);
    caption = ['مقدار تغییر در سیستم به ازای ماتریس Q=', num2str(j)];
    disp(['Figure saved as figure_Q_', num2str(j), '.png with caption: ', caption]);
end

A = [0 1 0 0;
     18.8936 -10.3111 0 70.6712;
     0 0 0 1;
     -2.1282 2.7197 0 -19.4162];

B = [0;-6.5684; 0; 1.7316];

C = [1 0 0 0;
     0 1 0 0;
     0 0 1 0;
     0 0 0 1];
D = 0;

n = size(A, 1);

A_aug= [ A  zeros(n,1)   ;-C(1,:)    0  ];
B_aug= [B;0];
C_aug=[C  zeros(n,1)]   ;

Co=ctrb(A_aug, B_aug);
rank_Co=rank(Co);

disp('رنک سیستم:');
disp(rank_Co);

if rank_Co == size(A_aug ,1 )
   disp("سیستم قابل کنترل است");
else
     disp("سیستم قابل کنترل نیست") ;
end

[Q, R] = qr(Co);
A_c = Q'*A_aug*Q  ;
B_c = Q'*B_aug;
C_c =  C_aug*Q    ;

A_c_cont = A_c(1:rank_Co,1:rank_Co)  ;
B_c_cont =  B_c(1: rank_Co ,:) ;
C_c_cont=C_aug * Q  (:, 1:rank_Co);

p=[-2,-3,-4,-5];
K = place(  A_c_cont,   B_c_cont,p  )  ;

sys_cont= ss( A_c_cont  - B_c_cont*K ,   B_c_cont   ,  C_c_cont,  D  );

time_vector = 0:0.001:5  ;
t_sim =5;
r=1;
U= ones(length(time_vector),1)*r    ;

[Y_cl,T,X_cl ] = lsim (   sys_cont ,  U , time_vector   )   ;

figure
subplot(3,1,1);
   plot(time_vector , Y_cl(:,1))
     title("theta");

    subplot(3,1,2) ;
     plot(time_vector , Y_cl(:,2));
     title("theta\_dot");
    subplot(3,1,3)   ;
   plot(time_vector, Y_cl(:,3))   ;
     title('x') ;
sgtitle("پاسخ سیستم کنترلی ctrb") ;
saveas(gcf, 'figure1_control_response_orthogonal.png');


disturbance_amp  =0.1  ;
disturbance_freq =  2   ;
disturbance_signal  =   disturbance_amp*  sin (2*pi *  disturbance_freq *  time_vector )'    ;
[ Y_dis ,T ,X_dis  ]= lsim(  sys_cont ,  U+  disturbance_signal   ,   time_vector   );

 figure ;
  plot(time_vector,   disturbance_signal  );
   title('سیگنال اغتشاش') ;
     xlabel('زمان')  ;
 ylabel("مقدار سیگنال ")   ;
 saveas(gcf, 'figure2_disturbance_signal.png');


   figure  ;
   subplot(3,1,1) ;
  plot(time_vector,Y_dis(:,1));
   title("theta");
   subplot(3,1,2);
plot(time_vector, Y_dis(:,2));
    title("theta\_dot");
  subplot(3,1,3);
 plot(time_vector ,Y_dis(:,3))  ;
 title("x")
 sgtitle("خروجی ها با اغتشاش سینوسی")   ;
 saveas(gcf, 'figure3_output_with_disturbance.png');


 num_simulations= 1 ;
  deviation =0.02;

 for  j =1 : num_simulations
      A_perturbed  =  A   + deviation *   (rand (4,4)  - 0.5);
  A_perturbed_augmented  =[ A_perturbed   zeros(n,1);    -C(1,:)       0      ];
 [Q_p, R_p] =  qr( ctrb(  A_perturbed_augmented   , B_aug ))  ;
A_c_pert =Q_p'   * A_perturbed_augmented  * Q_p    ;
 B_c_pert  =  Q_p'* B_aug      ;
C_c_pert = C_aug * Q_p    ;
   rank_co_per= rank  (  ctrb(    A_perturbed_augmented , B_aug   ) )  ;
  A_c_cont_pert  =   A_c_pert (   1:rank_co_per     ,   1:rank_co_per)  ;
 B_c_cont_pert =  B_c_pert(1: rank_co_per, : )  ;
   C_c_cont_pert = C_c_pert(  : , 1: rank_co_per )    ;

p=[-2,-3,-4,-5, -6];
K = place(  A_c_cont_pert,   B_c_cont_pert,p  )  ;
sys_per  = ss(  A_c_cont_pert -B_c_cont_pert*K  ,    B_c_cont_pert  ,   C_c_cont_pert,   D );
[Y_p  ,T ,X_p  ] =  lsim(sys_per   ,   U, time_vector  )  ;
    figure  ;
    subplot(3,1,1);
 plot(time_vector  ,   Y_p(:,1))  ;
     title("theta")  ;
subplot(3,1,2)    ;
    plot(time_vector  ,Y_p(:,2))     ;
   title("theta\_dot");
subplot(3,1,3);
  plot(time_vector ,  Y_p(:,3))   ;
    title('x');
  sgtitle("سیستم ctrb در عدم قطعیت");
  saveas(gcf, 'figure4_orthogonal_uncertainty.png');
 end

  disp('بهره کنترلر زیرفضای کنترل:');
   disp(K);

A = [0 1 0 0; 18.8936 -10.3111 0 70.6712; 0 0 0 1; -2.1282 2.7197 0 -19.4162];
B = [0; -6.5684; 0; 1.7316];
C = [1 0 0 0; 0 1 0 0; 0 0 1 0; 0 0 0 1];
D = 0;

p = [-5, -8, -10, -12];
K = place(A, B, p);

x0 = [0.1; 0; 0; 0; 0; 0];
tspan = 0:0.01:5;

[t_nonlinear, x_nonlinear] = ode45(@(t, x) nonlinear_system(t,x,A, B, K), tspan, x0);

function dx = nonlinear_system(t,x, A, B, K)
    theta_b = x(1);
    theta_b_dot = x(2);
    x_lin = x(3);
    x_lin_dot = x(4);
    delta = x(5);
    delta_dot= x(6);

    u_a1 = - K * [theta_b; theta_b_dot ; x_lin; x_lin_dot ]   ;
    u_a2 = 0;

    dx=zeros(6,1);
    dx(1)=x(2);
    dx(2) = 18.8936 * theta_b_dot - 10.3111 * theta_b + 70.6712*x_lin - 6.5684* u_a1 ;
    dx(3)= x(4);
    dx(4) = -2.1282*theta_b_dot+ 2.7197*theta_b  -19.4162 *x_lin  +   1.7316* u_a1     ;
    dx(5) = x(6);
    dx(6) = -10.2274 * delta_dot + 3.5414*u_a2 ;
end

time_vector = 0:0.001:tspan(end);
r =1  ;
figure
for i=1:4
    [ Y_out ] = lsim ( ss(A-B*K,B,C,D)  , ones (length (time_vector) ,1)*r   ,  time_vector )     ;
    subplot(4,1,i);
    plot(time_vector,Y_out(:,i)   ) ;
    title(['output' num2str(i)])  ;
    ylabel(['y' num2str(i)]);
    if i==4
        xlabel('Time(sec)')
    end
end;
sgtitle("Step Response");
saveas(gcf, 'Step_Response.png');

figure
for i=1:4
    subplot(4,1,i)
    plot(t_nonlinear,x_nonlinear(:,i));
    ylabel(['x' num2str(i)]);
    if i==4
        xlabel('Time(sec)');
    end
end;
sgtitle("State Variables")
saveas(gcf, 'State_Variables.png');

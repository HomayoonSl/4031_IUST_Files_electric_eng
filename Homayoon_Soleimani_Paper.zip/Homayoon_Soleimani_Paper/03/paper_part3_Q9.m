% ماتریس‌های سیستم
A = [0 1 0 0;
     18.8936 -10.3111 0 70.6712;
     0 0 0 1;
     -2.1282 2.7197 0 -19.4162];

B = [0;-6.5684; 0; 1.7316];

C = [1 0 0 0;
     0 1 0 0;
     0 0 1 0;
     0 0 0 1];
D = 0;

% طراحی تخمینگر
p_observer = [-10, -11, -12, -13];
L = place(A', C', p_observer)';

% مدل فضای حالت
sys = ss(A, B, C, D);
A_observer = A - L * C;
sys_observer = ss(A_observer, B, C, D);

% شبیه‌سازی
time_vector = 0:0.001:5;
initial_condition = [0.005, 0.1, 0, 0];
U = zeros(length(time_vector), size(B, 2));

[Y_system, T, X_system] = lsim(sys, U, time_vector, initial_condition);
[Y_observer, T, X_observer] = lsim(sys_observer, U , time_vector, initial_condition);

e = X_system - X_observer;

% نمودار خروجی
figure;
subplot(3, 1, 1);
plot(time_vector, X_system(:, 1));
hold on;
plot(time_vector, X_observer(:, 1));
title('theta');
legend("سیستم اصلی", "تخمینگر");

subplot(3, 1, 2);
plot(time_vector, X_system(:, 2));
hold on;
plot(time_vector, X_observer(:, 2));
title('theta\_dot');
legend("سیستم اصلی", "تخمینگر");

subplot(3, 1, 3);
plot(time_vector, X_system(:, 3));
hold on;
plot(time_vector, X_observer(:, 3));
title('x');
legend("سیستم اصلی", "تخمینگر");
sgtitle('خروجی‌ها');
saveas(gcf, 'outputs.png');

% نمودار خطا
figure;
subplot(3, 1, 1);
plot(time_vector, e(:, 1));
title('خطا theta');

subplot(3, 1, 2);
plot(time_vector, e(:, 2));
title('خطا theta\_dot');

subplot(3, 1, 3);
plot(time_vector, e(:, 3));
title('خطا x');
sgtitle('خطا');
saveas(gcf, 'errors.png');

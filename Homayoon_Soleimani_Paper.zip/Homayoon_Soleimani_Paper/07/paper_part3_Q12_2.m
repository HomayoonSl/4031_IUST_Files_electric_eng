% ماتریس‌های سیستم
A = [0 1 0 0;
     18.8936 -10.3111 0 70.6712;
     0 0 0 1;
     -2.1282 2.7197 0 -19.4162];

B = [0;-6.5684; 0; 1.7316];
C = [1 0 0 0;
    0 1 0 0;
    0 0 1 0;
    0 0 0 1];

D = 0;

% ماتریس‌های وزن‌دهی
Q = diag([100, 100, 100, 100]); 
R = 1;  

% طراحی کنترلر LQR
[K, S, e] = lqr(A, B, Q, R);

% قطبهای حلقه بسته
A_cl = A - B*K;
poles_cl = eig(A_cl);

% شبیه‌سازی
t = 0:0.01:5;
sys_cl = ss(A_cl, B, C, D);

r = 1;
figure;
Y_lqr = lsim(sys_cl, ones(size(t, 2), 1) * r, t);

for i = 1:size(Y_lqr, 2)
    subplot(size(Y_lqr, 2), 1, i);
    plot(t, Y_lqr(:, i));
    title(['State Variable ', num2str(i)]);
    if i == size(Y_lqr, 2)
        xlabel('Time (sec)');
    end
end
sgtitle('پاسخ سیستم حلقه بسته با LQR و ورودی پله');
saveas(gcf, 'closed_loop_response.png');

disp('K:');
disp(K);

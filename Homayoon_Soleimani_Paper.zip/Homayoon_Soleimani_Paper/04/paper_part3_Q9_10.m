A = [0 1 0 0; 18.8936 -10.3111 0 70.6712; 0 0 0 1; -2.1282 2.7197 0 -19.4162];
B = [0;-6.5684; 0; 1.7316];
C = [1 0 0 0; 0 1 0 0; 0 0 1 0; 0 0 0 1];
D = 0;

Ob = obsv(A, C);
rank_Ob = rank(Ob);

if rank_Ob == size(A, 1)
    disp('سیستم رویت پذير است');
else
    disp('سیستم رویت پذیر نیست');
end

[V, E] = eig(A);
for i = 1:size(E, 1)
    if real(E(i, i)) >= 0
        disp('سیستم ناپايدار است');
        disp("قطب های ناپايدار:");
        disp(E(i, i));
    end
end

[Q, R] = qr(Ob');

A_o = Q'*A*Q;
C_o = C*Q';

A_o_observer = A_o(1:rank_Ob, 1:rank_Ob);
B_o_observer = B;
C_o_observer = C_o(:, 1:rank_Ob);

p_reduced = [-2, -3, -4, -5] ;
L_reduced = place(A_o_observer', C_o_observer', p_reduced)';

A_reduced_obs = A_o_observer - L_reduced*C_o_observer;
B_reduced_obs = L_reduced;
C_reduced_obs = eye(size(A_o_observer, 1));

sys_reduced = ss(A_reduced_obs, B_reduced_obs, C_reduced_obs, D);
sys = ss(A, B, C, D);

time_vector = 0:0.001:5;
t_sim = 5;
initial_condition = [0.005, 0.1, 0, 0];
U = zeros(length(time_vector), size(B, 2));

[Y, T, X] = lsim(sys, U, time_vector, initial_condition);

[Y_r, T, X_r] = lsim(sys_reduced, Y, time_vector, initial_condition(1:rank_Ob) );

e_reduced = X(:, 1:rank_Ob) - X_r;

figure;
subplot(3, 1, 1);
plot(time_vector, X(:, 1), 'b', time_vector, X_r(:, 1), 'r--');
title('تتا');
legend('سیستم اصلی', 'تخمین‌گر');

subplot(3, 1, 2);
plot(time_vector, X(:, 2), 'b', time_vector, X_r(:, 2), 'r--');
title('تتادات');
legend('سیستم اصلی', 'تخمین‌گر');

subplot(3, 1, 3);
plot(time_vector, X(:, 3), 'b', time_vector, X_r(:, 1) , 'r--');
title("x");
legend("سیستم اصلی","تخمین‌گر")   ;
sgtitle("خروجی‌ها")
saveas(gcf, 'outputs.png');

figure
subplot(2, 1, 1);
plot(time_vector, e_reduced(:, 1));
title('خطای تتا');

subplot(2, 1, 2);
plot(time_vector, e_reduced(:, 2));
title('خطای تتادات');
sgtitle("خطای تخمین‌گر");
saveas(gcf, 'errors.png');

A = [0 1 0 0;
     18.8936 -10.3111 0 70.6712;
     0 0 0 1;
     -2.1282 2.7197 0 -19.4162];

B = [0;-6.5684; 0; 1.7316];


C = [1 0 0 0;
0 1 0 0;
0 0 1 0;
0 0 0 1];

D = [0; 0; 0; 0];
sys_ol = ss(A,B,C,D);
poles = eig(A);
disp('Open-loop poles:');
disp(poles);
K = [-40.9839 -13.8993 -10 24.6190];
A_closed_loop = A - B*K;
poles_closed_loop = eig(A_closed_loop);
sys_closed_loop = ss(A_closed_loop, B, C, D);
sys_tf= tf(sys_closed_loop);
[num , den]=tfdata(sys_tf, 'v');
disp('Closed-loop poles with given K:');
disp(poles_closed_loop);

Co = ctrb(A, B);
rank_Co = rank(Co);
Ob = obsv(A, C);
rank_Ob = rank(Ob);

disp('Controllability matrix rank:');
disp(rank_Co);
disp('Observability matrix rank:');
disp(rank_Ob);

if rank_Co == size(A, 1)
    disp('Open-loop system is controllable.');
else
    disp('Open-loop system is not controllable.');
end

if rank_Ob == size(A, 1)
    disp('Open-loop system is observable.');
else
    disp('Open-loop system is not observable.');
end

time_vector= 0:0.01:5;
t_sim= 5;
sys_ol = ss(A,B,C,D);

figure;
Y = step(sys_ol, time_vector);
for i = 1:4
    subplot(4,1,i)
    plot(time_vector, Y(:,i))
     ylabel(['Output ', num2str(i)]);
      if i==4
          xlabel('Time (s)')
      end
end
sgtitle('Open-loop step response')
saveas(gcf, 'open_loop_step_response.png');

figure;
initial_condition= [0.005 0.1 0 0 ];
[Y,T,X] = initial(sys_ol,initial_condition ,time_vector );
for i = 1:4
    subplot(4,1,i)
    plot(time_vector, X(:,i))
     ylabel(['State ', num2str(i)]);
       if i==4
           xlabel('Time (s)')
      end
end
sgtitle('Open-loop state variables')
saveas(gcf, 'open_loop_state_variables.png');


p_far = [-15, -20, -25, -30];
K_far = place(A, B, p_far);
A_closed_loop_far = A - B * K_far;
sys_closed_loop_far= ss(A_closed_loop_far,B,C,D);


figure;
Y_far= step(sys_closed_loop_far,time_vector);
for i = 1:4
    subplot(4,1,i)
    plot(time_vector, Y_far(:,i))
        ylabel(['Output ', num2str(i)]);
           if i==4
                 xlabel('Time (s)')
           end
end
sgtitle('Step response (Far Poles)');
saveas(gcf, 'step_response_far_poles.png');


figure
initial_condition_far= [0.005 0.1 0 0 ];
[Y,T,X_far] = initial(sys_closed_loop_far,initial_condition_far,time_vector);
for i = 1:4
      subplot(4,1,i)
        plot(time_vector, X_far(:,i))
       ylabel(['State ', num2str(i)]);
       if i==4
        xlabel('Time (s)')
      end
end
sgtitle('State variables (Far Poles)');
saveas(gcf, 'state_variables_far_poles.png');

p_near = [-1, -2, -3, -4];
K_near = place(A, B, p_near);
A_closed_loop_near = A - B * K_near;
sys_closed_loop_near= ss(A_closed_loop_near,B,C,D);

figure;
Y_near = step(sys_closed_loop_near, time_vector);

for i = 1:4
    subplot(4,1,i)
    plot(time_vector, Y_near(:,i))
        ylabel(['Output ', num2str(i)]);
          if i==4
                 xlabel('Time (s)')
           end
end
sgtitle('Step response (Near Poles)');
saveas(gcf, 'step_response_near_poles.png');


figure;
initial_condition_near= [0.005 0.1 0 0 ];
[Y,T,X_near] = initial(sys_closed_loop_near,initial_condition_near ,time_vector);
for i = 1:4
        subplot(4,1,i)
        plot(time_vector, X_near(:,i))
         ylabel(['State ', num2str(i)]);
        if i==4
              xlabel('Time (s)')
      end
end
sgtitle('State variables (Near Poles)');
saveas(gcf, 'state_variables_near_poles.png');

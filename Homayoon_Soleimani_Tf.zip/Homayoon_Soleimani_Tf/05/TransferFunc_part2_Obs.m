num = [6 18];
den = [1 3 -13.75 -31.5];
T = tf(num, den);
[A, B, C, D] = tf2ss(num, den);
poles_desired = [-5+5i, -5-5i, -10];
observer_poles_slow = poles_desired - 5;
observer_poles_fast = poles_desired - 20;
L_slow = acker(A', C', observer_poles_slow)';
L_fast = acker(A', C', observer_poles_fast)';

% Assuming K is defined somewhere, if not, you will need to define it
% For example, if you want to use pole placement for controller as well:
controller_poles = [-15, -20, -25]; % Example controller poles
K = acker(A, B, controller_poles);


T_sim = 5;
t_sim = linspace(2.5, T_sim, 500);
r = ones(size(t_sim));

x0 = [1; -1; 0.5];
x_hat0_slow = [0; 0; 0];
x_hat0_fast = [0; 0; 0];

x_slow = zeros(3, length(t_sim));
x_hat_slow = zeros(3, length(t_sim));
y_slow = zeros(size(C,1), length(t_sim));
y_measured_slow = zeros(size(C,1), length(t_sim));
u_slow = zeros(size(B,2), length(t_sim));

x_slow(:,1) = x0;
x_hat_slow(:,1) = x_hat0_slow;
y_slow(:,1) = C*x_slow(:,1) + D*r(1);
y_measured_slow(:,1) = C*x_slow(:,1) + D*r(1);

for i = 1:length(t_sim)-1
    dt = t_sim(i+1) - t_sim(i);
    u_slow(:,i) = -K * x_hat_slow(:,i);
    x_dot_slow = A*x_slow(:,i) + B*u_slow(:,i);
    x_slow(:,i+1) = x_slow(:,i) + x_dot_slow * dt;
    y_slow(:,i+1) = C*x_slow(:,i+1) + D*r(i+1);
    y_measured_slow(:,i+1) = C*x_slow(:,i+1) + D*r(i+1);
    x_hat_dot_slow = A*x_hat_slow(:,i) + B*u_slow(:,i) + L_slow*(y_measured_slow(:,i+1) - C*x_hat_slow(:,i));
    x_hat_slow(:,i+1) = x_hat_slow(:,i) + x_hat_dot_slow * dt;
end

x_fast = zeros(3, length(t_sim));
x_hat_fast = zeros(3, length(t_sim));
y_fast = zeros(size(C,1), length(t_sim));
y_measured_fast = zeros(size(C,1), length(t_sim));
u_fast = zeros(size(B,2), length(t_sim));

x_fast(:,1) = x0;
x_hat_fast(:,1) = x_hat0_fast;
y_fast(:,1) = C*x_fast(:,1) + D*r(1);
y_measured_fast(:,1) = C*x_fast(:,1) + D*r(1);

for i = 1:length(t_sim)-1
    dt = t_sim(i+1) - t_sim(i);
    u_fast(:,i) = -K * x_hat_fast(:,i);
    x_dot_fast = A*x_fast(:,i) + B*u_fast(:,i);
    x_fast(:,i+1) = x_fast(:,i) + x_dot_fast * dt;
    y_fast(:,i+1) = C*x_fast(:,i+1) + D*r(i+1);
    y_measured_fast(:,i+1) = C*x_fast(:,i+1) + D*r(i+1);
    x_hat_dot_fast = A*x_hat_fast(:,i) + B*u_fast(:,i) + L_fast*(y_measured_fast(:,i+1) - C*x_hat_fast(:,i));
    x_hat_fast(:,i+1) = x_hat_fast(:,i) + x_hat_dot_fast * dt;
end

estimation_error_slow = x_slow - x_hat_slow;
estimation_error_fast = x_fast - x_hat_fast;

fig1 = figure;
fig1.Name = 'State Estimation - Slow vs Fast Observer';

subplot(3, 2, 1);
plot(t_sim, x_slow(1,:), 'b-', t_sim, x_hat_slow(1,:), 'r--');
xlabel('Time'); ylabel('x_1, x_1-hat'); title('x_1 - Slow Observer'); legend('x_1', 'x_1-hat');
subplot(3, 2, 3);
plot(t_sim, x_slow(2,:), 'b-', t_sim, x_hat_slow(2,:), 'r--');
xlabel('Time'); ylabel('x_2, x_2-hat'); title('x_2 - Slow Observer'); legend('x_2', 'x_2-hat');
subplot(3, 2, 5);
plot(t_sim, x_slow(3,:), 'b-', t_sim, x_hat_slow(3,:), 'r--');
xlabel('Time'); ylabel('x_3, x_3-hat'); title('x_3 - Slow Observer'); legend('x_3', 'x_3-hat');

subplot(3, 2, 2);
plot(t_sim, x_fast(1,:), 'b-', t_sim, x_hat_fast(1,:), 'r--');
xlabel('Time'); ylabel('x_1, x_1-hat'); title('x_1 - Fast Observer'); legend('x_1', 'x_1-hat');
subplot(3, 2, 4);
plot(t_sim, x_fast(2,:), 'b-', t_sim, x_hat_fast(2,:), 'r--');
xlabel('Time'); ylabel('x_2, x_2-hat'); title('x_2 - Fast Observer'); legend('x_2', 'x_2-hat');
subplot(3, 2, 6);
plot(t_sim, x_fast(3,:), 'b-', t_sim, x_hat_fast(3,:), 'r--');
xlabel('Time'); ylabel('x_3, x_3-hat'); title('x_3 - Fast Observer'); legend('x_3', 'x_3-hat');

% Save Figure 1
filename1 = strrep(fig1.Name, ' ', '_'); % Replace spaces with underscores for filename
savefig(fig1, [filename1, '.fig']);
saveas(fig1, [filename1, '.png']);


fig2 = figure;
fig2.Name = 'Estimation Errors - Slow vs Fast Observer';

subplot(3, 2, 1);
plot(t_sim, estimation_error_slow(1,:));
xlabel('Time'); ylabel('e_1'); title('e_1 - Slow Observer');
subplot(3, 2, 3);
plot(t_sim, estimation_error_slow(2,:));
xlabel('Time'); ylabel('e_2'); title('e_2 - Slow Observer');
subplot(3, 2, 5);
plot(t_sim, estimation_error_slow(3,:));
xlabel('Time'); ylabel('e_3'); title('e_3 - Slow Observer');

subplot(3, 2, 2);
plot(t_sim, estimation_error_fast(1,:));
xlabel('Time'); ylabel('e_1'); title('e_1 - Fast Observer');
subplot(3, 2, 4);
plot(t_sim, estimation_error_fast(2,:));
xlabel('Time'); ylabel('e_2'); title('e_2 - Fast Observer');
subplot(3, 2, 6);
plot(t_sim, estimation_error_fast(3,:));
xlabel('Time'); ylabel('e_3'); title('e_3 - Fast Observer');

% Save Figure 2
filename2 = strrep(fig2.Name, ' ', '_');
savefig(fig2, [filename2, '.fig']);
saveas(fig2, [filename2, '.png']);


fig3 = figure;
fig3.Name = 'Control Signals - Slow vs Fast Observer';

subplot(2, 1, 1);
plot(t_sim, u_slow);
xlabel('Time'); ylabel('u'); title('Control - Slow Observer');
subplot(2, 1, 2);
plot(t_sim, u_fast);
xlabel('Time'); ylabel('u'); title('Control - Fast Observer');

% Save Figure 3
filename3 = strrep(fig3.Name, ' ', '_');
savefig(fig3, [filename3, '.fig']);
saveas(fig3, [filename3, '.png']);

num = [6 18];
den = [1 3 -13.75 -31.5];
T = tf(num, den);
[A, B, C, D] = tf2ss(num, den);
poles_desired = [-5+5i, -5-5i, -10];
observer_poles_slow = poles_desired - 5;
observer_poles_fast = poles_desired - 20;
L_slow = acker(A', C', observer_poles_slow)';
L_fast = acker(A', C', observer_poles_fast)';
K = place(A,B,poles_desired); % K را اینجا تعریف کنید

T_sim = 5;
t_sim = linspace(0, T_sim, 500);
r = ones(size(t_sim));

x0 = [1; -1; 0.5];
x_hat0_slow = [0; 0; 0];
x_hat0_fast = [0; 0; 0];

x_slow = zeros(3, length(t_sim));
x_hat_slow = zeros(3, length(t_sim));
y_slow = zeros(size(C,1), length(t_sim));
y_measured_slow = zeros(size(C,1), length(t_sim));
u_slow = zeros(size(B,2), length(t_sim));

x_slow(:,1) = x0;
x_hat_slow(:,1) = x_hat0_slow;
y_slow(:,1) = C*x_slow(:,1) + D*r(1);
y_measured_slow(:,1) = C*x_slow(:,1) + D*r(1);

for i = 1:length(t_sim)-1
    dt = t_sim(i+1) - t_sim(i);
    u_slow(:,i) = -K * x_hat_slow(:,i);
    x_dot_slow = A*x_slow(:,i) + B*u_slow(:,i);
    x_slow(:,i+1) = x_slow(:,i) + x_dot_slow * dt;
    y_slow(:,i+1) = C*x_slow(:,i+1) + D*r(i+1);
    y_measured_slow(:,i+1) = C*x_slow(:,i+1) + D*r(i+1);
    x_hat_dot_slow = A*x_hat_slow(:,i) + B*u_slow(:,i) + L_slow*(y_measured_slow(:,i+1) - C*x_hat_slow(:,i));
    x_hat_slow(:,i+1) = x_hat_slow(:,i) + x_hat_dot_slow * dt;
end

x_fast = zeros(3, length(t_sim));
x_hat_fast = zeros(3, length(t_sim));
y_fast = zeros(size(C,1), length(t_sim));
y_measured_fast = zeros(size(C,1), length(t_sim));
u_fast = zeros(size(B,2), length(t_sim));

x_fast(:,1) = x0;
x_hat_fast(:,1) = x_hat0_fast;
y_fast(:,1) = C*x_fast(:,1) + D*r(1);
y_measured_fast(:,1) = C*x_fast(:,1) + D*r(1);

for i = 1:length(t_sim)-1
    dt = t_sim(i+1) - t_sim(i);
    u_fast(:,i) = -K * x_hat_fast(:,i);
    x_dot_fast = A*x_fast(:,i) + B*u_fast(:,i);
    x_fast(:,i+1) = x_fast(:,i) + x_dot_fast * dt;
    y_fast(:,i+1) = C*x_fast(:,i+1) + D*r(i+1);
    y_measured_fast(:,i+1) = C*x_fast(:,i+1) + D*r(i+1);
    x_hat_dot_fast = A*x_hat_fast(:,i) + B*u_fast(:,i) + L_fast*(y_measured_fast(:,i+1) - C*x_hat_fast(:,i));
    x_hat_fast(:,i+1) = x_hat_fast(:,i) + x_hat_dot_fast * dt;
end

estimation_error_slow = x_slow - x_hat_slow;
estimation_error_fast = x_fast - x_hat_fast;

fig1 = figure; % ذخیره هندل فیگور
subplot(3, 2, 1);
plot(t_sim, x_slow(1,:), 'b-', t_sim, x_hat_slow(1,:), 'r--');
xlabel('Time'); ylabel('States'); title('x_1 - Slow Observer'); legend('Actual', 'Estimated');
subplot(3, 2, 3);
plot(t_sim, x_slow(2,:), 'b-', t_sim, x_hat_slow(2,:), 'r--');
xlabel('Time'); ylabel('States'); title('x_2 - Slow Observer'); legend('Actual', 'Estimated');
subplot(3, 2, 5);
plot(t_sim, x_slow(3,:), 'b-', t_sim, x_hat_slow(3,:), 'r--');
xlabel('Time'); ylabel('States'); title('x_3 - Slow Observer'); legend('Actual', 'Estimated');

subplot(3, 2, 2);
plot(t_sim, x_fast(1,:), 'b-', t_sim, x_hat_fast(1,:), 'r--');
xlabel('Time'); ylabel('States'); title('x_1 - Fast Observer'); legend('Actual', 'Estimated');
subplot(3, 2, 4);
plot(t_sim, x_fast(2,:), 'b-', t_sim, x_hat_fast(2,:), 'r--');
xlabel('Time'); ylabel('States'); title('x_2 - Fast Observer'); legend('Actual', 'Estimated');
subplot(3, 2, 6);
plot(t_sim, x_fast(3,:), 'b-', t_sim, x_hat_fast(3,:), 'r--');
xlabel('Time'); ylabel('States'); title('x_3 - Fast Observer'); legend('Actual', 'Estimated');

sgtitle('مقایسه حالت تخمین زده شده و حالت واقعی برای مشاهده گرهای کند و سریع'); % اضافه کردن عنوان برای کل فیگور
saveas(fig1, 'figure1_state_estimation.png'); % ذخیره فیگور با کپشن

fig2 = figure; % ذخیره هندل فیگور
subplot(3, 2, 1);
plot(t_sim, estimation_error_slow(1,:));
xlabel('Time'); ylabel('Error'); title('e_1 - Slow Observer');
subplot(3, 2, 3);
plot(t_sim, estimation_error_slow(2,:));
xlabel('Time'); ylabel('Error'); title('e_2 - Slow Observer');
subplot(3, 2, 5);
plot(t_sim, estimation_error_slow(3,:));
xlabel('Time'); ylabel('Error'); title('e_3 - Slow Observer');

subplot(3, 2, 2);
plot(t_sim, estimation_error_fast(1,:));
xlabel('Time'); ylabel('Error'); title('e_1 - Fast Observer');
subplot(3, 2, 4);
plot(t_sim, estimation_error_fast(2,:));
xlabel('Time'); ylabel('Error'); title('e_2 - Fast Observer');
subplot(3, 2, 6);
plot(t_sim, estimation_error_fast(3,:));
xlabel('Time'); ylabel('Error'); title('e_3 - Fast Observer');

sgtitle('خطای تخمین برای مشاهده گرهای کند و سریع'); % اضافه کردن عنوان برای کل فیگور
saveas(fig2, 'figure2_estimation_error.png'); % ذخیره فیگور با کپشن
fig3 = figure; % ذخیره هندل فیگور
subplot(2, 1, 1);
plot(t_sim, u_slow);
xlabel('Time'); ylabel('Control'); title('Control - Slow Observer');
subplot(2, 1, 2);
plot(t_sim, u_fast);
xlabel('Time'); ylabel('Control'); title('Control - Fast Observer');

sgtitle('سیگنال کنترل برای مشاهده گرهای کند و سریع'); % اضافه کردن عنوان برای کل فیگور
saveas(fig3, 'figure3_control_signal.png'); % ذخیره فیگور با کپشن

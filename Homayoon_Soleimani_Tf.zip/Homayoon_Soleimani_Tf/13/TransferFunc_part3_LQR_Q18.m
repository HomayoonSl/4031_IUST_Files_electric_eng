%% --- Optimal State Feedback Design (LQR) - ORIGINAL SYSTEM

%% --- 1:  System Model in State Space
num_lqr = [6 18];
den_lqr = [1 3 -13.75 -31.5];
T_lqr = tf(num_lqr, den_lqr);
[A_lqr, B_lqr, C_lqr, D_lqr] = tf2ss(num_lqr, den_lqr);
sys_lqr= ss(A_lqr, B_lqr, C_lqr, D_lqr);

%% --- 2 :  Simulation time and Input
t_lqr = linspace(0, 5, 500);
x0_lqr = [1; -1; 0.5];
r_lqr = ones(size(t_lqr));

% --- 3 : LQR parameters setup
Q_fixed = diag([1, 1, 1]);
R_values = [0.01, 0.1, 1, 10];

R_fixed = 1;
Q_values=  [diag([1 1 1]) , diag([5, 5, 5]), diag([10 10 10]), diag([100,100,100])] ;


%% 4a---LQR Design loop (Constant Q, varying R)

figure; hold on ;
set (gca,'fontsize',14);


 for k = 1:length(R_values)

   R = R_values(k);

      [K_lqr, S, e] = lqr(A_lqr, B_lqr, Q_fixed, R);
  sys_lqr_cl_r_tuning = ss(A_lqr - B_lqr * K_lqr, B_lqr, C_lqr, D_lqr);

     t_lqr_sim = linspace(0,5, 500)  ;
   [y_lqr_cl,t_sim_state] = step(sys_lqr_cl_r_tuning, t_lqr_sim) ;
       plot(t_sim_state , y_lqr_cl  ,'LineWidth',2);

   end;


grid on
xlabel('Time (sec)'); ylabel('Output Trajectories')
title('System Responses (Constant Q, Varying R)')

   legend_str = [ 'R= ' num2str(R_values(1)), ' ' , 'R= ' num2str(R_values(2)),  ' ' ,  'R= ' num2str(R_values(3)),  ' ' ,  'R= ' num2str(R_values(4))];
legend (legend_str) ;

% --- اضافه شده برای ذخیره فیگور با کپشن ---
title_str_fig1 = 'System_Responses_Constant_Q_Varying_R'; % یه اسم فایل خوشگل
saveas(gcf, title_str_fig1, 'png'); % با فرمت png ذخیره کن، فرمت‌های دیگه هم میشه


 %% 4b---  LQR Design (Constant R, varied Q)

figure;  hold on
 set (gca,'fontsize',14);
Q_values=  { diag([1 1 1]) , diag([5 5 5]), diag([10 10 10]), diag([100,100,100])} ;
  for m = 1:length(Q_values)
   [K_lqr_q, S_q, e_q] = lqr(A_lqr, B_lqr, Q_values{m}, R_fixed);
    sys_lqr_cl_q_tuning = ss(A_lqr - B_lqr * K_lqr_q, B_lqr, C_lqr, D_lqr);

   [y_lqr_cl_q,t_sim_q] = step(sys_lqr_cl_q_tuning , t_lqr);
       plot(t_sim_q,y_lqr_cl_q, 'LineWidth',2);

end;


xlabel('Time (sec)'); ylabel('Output Trajectories')

  title(' System Output Responses (Fixed R, Varying Q)')


legend_str = [  ' Q(1)= [1 1 1]', ' ', 'Q(2)=[5 5 5]',   ' ',   'Q(3)=[10 10 10]'  , ' ','Q(4) = [100 100 100]'];
 legend (legend_str) ;

% --- اضافه شده برای ذخیره فیگور دوم با کپشن ---
title_str_fig2 = 'System_Output_Responses_Fixed_R_Varying_Q'; % اسم فایل دوم
saveas(gcf, title_str_fig2, 'png'); % اینم png ذخیره کن

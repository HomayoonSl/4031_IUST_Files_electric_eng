%% State Feedback - Fast vs Slow Poles

%% 1. System Model

num_fb = [6 18];
den_fb = [1 3 -13.75 -31.5];
T_fb = tf(num_fb, den_fb);
[A_fb, B_fb, C_fb, D_fb] = tf2ss(num_fb, den_fb);
sys_fb = ss(A_fb, B_fb, C_fb, D_fb)

%% 2. Fast Poles Feedback

poles_fast = [-25, -15+15i, -15-15i];
K_fast_fb = place(A_fb, B_fb, poles_fast);
sys_fast_cl = ss(A_fb-B_fb*K_fast_fb,B_fb, C_fb,D_fb);

%% 3. Slow Poles Feedback

poles_slow = [-7, -4+4i, -4-4i];
K_slow_fb = place(A_fb, B_fb, poles_slow);
sys_slow_cl = ss(A_fb -B_fb*K_slow_fb,B_fb, C_fb,D_fb);

%% 4. Simulation Parameters

t_sim_fb = linspace(0, 5, 500);
x0_fb = [1; -1; 0.5];
x_fast = zeros(3, length(t_sim_fb));
x_slow = zeros(3, length(t_sim_fb));
u_fast = zeros(size(B_fb, 2), length(t_sim_fb));
u_slow = zeros(size(B_fb, 2), length(t_sim_fb));
x_fast(:, 1) = x0_fb;
x_slow(:,1)= x0_fb;

%% 5. System Simulation

for i=1:length(t_sim_fb)-1
    dt = t_sim_fb(i+1) - t_sim_fb(i);

    u_fast(:, i) = -K_fast_fb*x_fast(:, i);
    x_dot_fast = A_fb*x_fast(:, i) + B_fb*u_fast(:, i);
    x_fast(:, i+1) =  x_fast(:, i)  + x_dot_fast*dt ;

    u_slow(:, i) = -K_slow_fb*x_slow(:, i);
    x_dot_slow = A_fb*x_slow(:, i)+ B_fb*u_slow(:, i);
    x_slow(:, i+1) = x_slow(:, i) +  x_dot_slow*dt;
end

%% 6. Plotting Results
fig1 = figure;

subplot(3, 2, 1);
plot(t_sim_fb, x_fast(1,:));
xlabel('Time'); ylabel('x_1'); title('State x_1 - Fast Poles');
subplot(3, 2, 3);
plot(t_sim_fb, x_fast(2,:));
xlabel('Time'); ylabel('x_2'); title('State x_2 - Fast Poles');
subplot(3, 2, 5);
plot(t_sim_fb, x_fast(3,:));
xlabel('Time'); ylabel('x_3'); title('State x_3 - Fast Poles');

subplot(3, 2, 2);
plot(t_sim_fb, x_slow(1,:));
xlabel('Time'); ylabel('x_1'); title('State x_1 - Slow Poles');
subplot(3, 2, 4);
plot(t_sim_fb, x_slow(2,:));
xlabel('Time'); ylabel('x_2'); title('State x_2 - Slow Poles');
subplot(3, 2, 6);
plot(t_sim_fb, x_slow(3,:));
xlabel('Time'); ylabel('x_3'); title('State x_3 - Slow Poles');

caption1 = 'State Responses - Fast vs Slow Poles';
saveas(gcf, sprintf('figure_states_%s.png', strrep(caption1, ' ', '_')));

fig2 = figure;
subplot(2, 1, 1);
plot(t_sim_fb, u_fast);
xlabel('Time'); ylabel('Control signal (u)'); title('Control Input u - Fast Poles');
subplot(2, 1, 2);
plot(t_sim_fb, u_slow);
xlabel('Time'); ylabel('Control Signal (u)'); title('Control Input u - Slow Poles');

caption2 = 'Control Input - Fast vs Slow Poles';
saveas(gcf, sprintf('figure_control_%s.png', strrep(caption2, ' ', '_')));

disp(' ');
disp('--- State Feedback Control - Fast/Slow Poles --');
disp('State responses from direct K gain.');
disp('Observer effects are not used.');
disp('Controllers designed with fast and slow pole placements.');
disp('Compare control efforts (u) and state profiles.');
disp('Simulation tests controller parameter choices: fast vs slower poles.');
disp('Differences in settling speeds and oscillations are visible.');
disp('Fast and slow parameter settings are the key differences.');
disp('Controller influence alone is highlighted.');

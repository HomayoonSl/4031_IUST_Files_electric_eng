#!/bin/bash
if [ "$#" -ne 1 ]; then
    echo "Usage: matlabOut <file.m>"
    exit 1
fi
input_file="$1"
if [ ! -f "$input_file" ]; then
    echo "Error: File '$input_file' not found!"
    exit 1
fi
base_name="${input_file%.m}"
output_file="${base_name}_output.txt"
matlab -nodesktop -nosplash -r "diary('$output_file'); run('$input_file'); diary off; exit;"


%% LQR Design - Original System

num_lqr = [6 18];
den_lqr = [1 3 -13.75 -31.5];
T_lqr = tf(num_lqr, den_lqr);
[A_lqr, B_lqr, C_lqr, D_lqr] = tf2ss(num_lqr, den_lqr);
sys_lqr = ss(A_lqr, B_lqr, C_lqr, D_lqr);

%% Simulation Parameters
t_lqr = linspace(0, 5, 500);
x0_lqr = [1; -1; 0.5];
r_lqr = ones(size(t_lqr));

Q_fixed = diag([1, 1, 1]);
R_values = [0.01, 0.1, 1, 10];

R_fixed = 1;
Q_values = { diag([1 1 1]) , diag([5, 5, 5]), diag([10 10 10]), diag([100,100,100])} ;


%% Simulation Implementation - R Loop

J_values_R = [];
J_values_Q = [];
output_states_from_Q  = [];
output_states_from_R = [];

figure; hold on;
set(gca,'fontsize',14);

for k = 1:length(R_values)

   R = R_values(k);
    [K_lqr, S, e] = lqr(A_lqr, B_lqr, Q_fixed, R);
    sys_lqr_cl = ss(A_lqr - B_lqr * K_lqr, B_lqr, C_lqr, D_lqr);
     [y_lqr_cl, t] = step(sys_lqr_cl, t_lqr);
      x_lqr = lsim(sys_lqr_cl, r_lqr, t_lqr, x0_lqr);

        cost_J_R = 0;
         u_lqr = -K_lqr' .* x_lqr';

      for  p= 1:length(t)-1
         dt = t(p+1) - t(p);
         cost_J_R  =  cost_J_R + (x_lqr(p, :) * Q_fixed * x_lqr(p, :).' + u_lqr(:,p)' * R * u_lqr(:,p)) * dt;
    end;

        J_values_R  =   [J_values_R   cost_J_R];
        output_states_from_R  =  [output_states_from_R ;  y_lqr_cl(:,end)];

           plot(t, y_lqr_cl, 'LineWidth',2)
 end

     legend_str = [ 'R= ' num2str(R_values(1)), ' ' , 'R= ' num2str(R_values(2)),  ' ' ,  'R= ' num2str(R_values(3)),  ' ' ,  'R= ' num2str(R_values(4))];
legend(legend_str)
title('LQR Designs, Output with Varying R');
grid on;
ylabel('Output');
xlabel('Time');

fig = gcf;
title_str = get(get(fig,'CurrentAxes'),'Title').String;
filename = strrep(title_str, ',', '_');
filename = strrep(filename, ' ', '_');
savefig(fig, [filename, '.fig']);
saveas(fig, [filename, '.png']);


disp('----- LQR Designs - Original System -----')

disp('--- Test 1: Varying R (Fixed Q) ---');

%disp(['J Values (R):', num2str(J_values_R)]);
%disp(['J Values (R): ', num2str(J_values_R(:).')]);
% disp('J Values (R):');
% disp(J_values_R);
for i = 1:size(J_values_R, 1)
    disp(['Row ', num2str(i), ': ', num2str(J_values_R(i, :))]);
end


    disp( 'Compare profiles during transition and steady state.');

disp('-- Last state values (R):');
disp('Output (R):');
disp(output_states_from_R);

% disp(['Output (R): ', num2str(output_states_from_R)]) ;
 disp('------ Next Test: Varying Q (Fixed R) -------');
 disp(' ');
 J_values_Q = [];
output_states_from_Q= []  ;


figure;hold on;
set (gca,'fontsize',14);

for m = 1:length(Q_values)
       if exist('MethodType', 'var') && MethodType == 2
           Q = Q_values{m};
      else
        Q=   Q_values{m};
      end;


  [K_lqr_q, S_q, e_q] = lqr(A_lqr, B_lqr, Q, R_fixed);
 sys_lqr_cl_q = ss(A_lqr - B_lqr * K_lqr_q, B_lqr, C_lqr, D_lqr);

 [y_lqr_cl_q ,t_q]  = step(sys_lqr_cl_q , t_lqr );

    x_lqr_q  =  lsim ( sys_lqr_cl_q,   r_lqr  ,t_lqr   , x0_lqr    );


          cost_J_Q =0  ;

             u_lqr_q= - K_lqr_q * x_lqr_q.' ;

      for p=1:length(t_q) - 1
        dt =  t_q(p+1)-  t_q(p);
       cost_J_Q =  cost_J_Q +  (x_lqr_q(p, :)*Q*x_lqr_q(p, :).'+ u_lqr_q(:,p)'*R_fixed*u_lqr_q(:,p) )* dt ;
      end;

      J_values_Q =[J_values_Q, cost_J_Q];
   output_states_from_Q = [  output_states_from_Q  ;  y_lqr_cl_q(:, end)] ;
  plot (t_q,  y_lqr_cl_q ,'LineWidth',2 )


   end;
 grid on
   legend_str = [  ' Q(1)= [1 1 1]', ' ', 'Q(2)=[5 5 5]',   ' ',   'Q(3)=[10 10 10]'  , ' ','Q(4) = [100 100 100]'];

    legend (legend_str ) ;
    title('LQR Designs (Varying Diagonal Q)');
 ylabel('Output (Varying Q)');
  xlabel ('Time')

fig = gcf;
title_str = get(get(fig,'CurrentAxes'),'Title').String;
filename = strrep(title_str, ',', '_');
filename = strrep(filename, ' ', '_');
savefig(fig, [filename, '.fig']);
saveas(fig, [filename, '.png']);


disp('----Design evaluation: LQR with Varying Q (Fixed R) ----') ;

  disp('J Values (Q):');
    disp(['J = ', num2str(J_values_Q)] )

   disp('Last states (Q):');
      disp(['Output y (Q): ',  num2str(output_states_from_Q )  ]) ;


disp('------ Visual Evaluations ------') ;
disp('Observe state transitions, output tracking, and settling times.');
disp('Compare performance with varying R and Q parameters.');

%% LQR Design - Original System

num_lqr = [6 18];
den_lqr = [1 3 -13.75 -31.5];
T_lqr = tf(num_lqr, den_lqr);
[A_lqr, B_lqr, C_lqr, D_lqr] = tf2ss(num_lqr, den_lqr);
sys_lqr = ss(A_lqr, B_lqr, C_lqr, D_lqr);

%% Simulation Parameters
t_lqr = linspace(0, 5, 500);
x0_lqr = [1; -1; 0.5];
r_lqr = ones(size(t_lqr));

Q_fixed = diag([1, 1, 1]);
R_values = [0.01, 0.1, 1, 10];
R_fixed = 1;
Q_values = { diag([1 1 1]) , diag([5, 5, 5]), diag([10 10 10]), diag([100,100,100])};

%% Simulation Implementation - R Loop
J_values_R = [];
output_states_from_R = [];

figure; hold on;
set(gca, 'fontsize', 14);
for k = 1:length(R_values)
    R = R_values(k);
    [K_lqr, S, e] = lqr(A_lqr, B_lqr, Q_fixed, R);
    sys_lqr_cl = ss(A_lqr - B_lqr * K_lqr, B_lqr, C_lqr, D_lqr);
    [y_lqr_cl, t] = step(sys_lqr_cl, t_lqr);
    x_lqr = lsim(sys_lqr_cl, r_lqr, t_lqr, x0_lqr);
    
    plot(t, y_lqr_cl, 'LineWidth', 2);
end
legend(arrayfun(@(r) sprintf('R = %.2f', r), R_values, 'UniformOutput', false));
title('LQR Design - Output with Varying R');
grid on;
ylabel('Output');
xlabel('Time');
savefig(gcf, 'LQR_Varying_R.fig');
saveas(gcf, 'LQR_Varying_R.png');

%% Individual Figures for R
for k = 1:length(R_values)
    figure;
    set(gca, 'fontsize', 14);
    R = R_values(k);
    [K_lqr, S, e] = lqr(A_lqr, B_lqr, Q_fixed, R);
    sys_lqr_cl = ss(A_lqr - B_lqr * K_lqr, B_lqr, C_lqr, D_lqr);
    [y_lqr_cl, t] = step(sys_lqr_cl, t_lqr);
    
    plot(t, y_lqr_cl, 'LineWidth', 2);
    title(['LQR Output for R = ', num2str(R)]);
    grid on;
    ylabel('Output');
    xlabel('Time');
    savefig(gcf, ['LQR_R_' num2str(R) '.fig']);
    saveas(gcf, ['LQR_R_' num2str(R) '.png']);
end

%% Simulation Implementation - Q Loop
J_values_Q = [];
output_states_from_Q = [];

figure; hold on;
set(gca, 'fontsize', 14);
for m = 1:length(Q_values)
    Q = Q_values{m};
    [K_lqr_q, S_q, e_q] = lqr(A_lqr, B_lqr, Q, R_fixed);
    sys_lqr_cl_q = ss(A_lqr - B_lqr * K_lqr_q, B_lqr, C_lqr, D_lqr);
    [y_lqr_cl_q, t_q] = step(sys_lqr_cl_q, t_lqr);
    
    plot(t_q, y_lqr_cl_q, 'LineWidth', 2);
end
legend(arrayfun(@(idx) sprintf('Q(%d) = [%d %d %d]', idx, Q_values{idx}(1,1), Q_values{idx}(2,2), Q_values{idx}(3,3)), 1:length(Q_values), 'UniformOutput', false));
title('LQR Design - Output with Varying Q');
grid on;
ylabel('Output');
xlabel('Time');
savefig(gcf, 'LQR_Varying_Q.fig');
saveas(gcf, 'LQR_Varying_Q.png');

%% Individual Figures for Q
for m = 1:length(Q_values)
    figure;
    set(gca, 'fontsize', 14);
    Q = Q_values{m};
    [K_lqr_q, S_q, e_q] = lqr(A_lqr, B_lqr, Q, R_fixed);
    sys_lqr_cl_q = ss(A_lqr - B_lqr * K_lqr_q, B_lqr, C_lqr, D_lqr);
    [y_lqr_cl_q, t_q] = step(sys_lqr_cl_q, t_lqr);
    
    plot(t_q, y_lqr_cl_q, 'LineWidth', 2);
    title(['LQR Output for Q(', num2str(m), ')']);
    grid on;
    ylabel('Output');
    xlabel('Time');
    savefig(gcf, ['LQR_Q_' num2str(m) '.fig']);
    saveas(gcf, ['LQR_Q_' num2str(m) '.png']);
end

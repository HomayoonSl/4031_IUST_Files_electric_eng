num = [6 18];
den = [1 3 -13.75 -31.5];
T = tf(num, den);
zeros_T = zero(T);
poles_T = pole(T);
disp('Zeros:');
disp(zeros_T);
disp('Poles:');
disp(poles_T);
if all(real(poles_T) < 0)
    disp('Open-loop system is stable.');
else
    disp('Open-loop system is unstable.');
end
if all(real(zeros_T) < 0)
    disp('System is minimum phase.');
else
    disp('System is non-minimum phase.');
end
disp('----------------------------------------------');

[A, B, C, D] = tf2ss(num, den);
disp('State-Space:');
disp('A:'); disp(A);
disp('B:'); disp(B);
disp('C:'); disp(C);
disp('D:'); disp(D);
fig1 = figure;
step(ss(A,B,C,D));
title('Step Response');
grid on;
caption1 = 'Figure 1: Step Response of Open-Loop System';
annotation('textbox', [0.1,0.01,0.8,0.05], 'String', caption1, 'FitBoxToText', 'on', 'HorizontalAlignment', 'center');
saveas(gcf, 'Figure1_StepResponse.png'); % Save as PNG
% savefig(fig1, 'Figure1_StepResponse.fig'); % Save as FIG for editable figure
disp('----------------------------------------------');

Mc = ctrb(A, B);
rank_Mc = rank(Mc);
Mo = obsv(A, C);
rank_Mo = rank(Mo);
disp('Controllability Rank:')
disp(rank_Mc)
disp('Observability Rank:')
disp(rank_Mo)
if rank_Mc == size(A, 1)
    disp('System is controllable.')
else
    disp('System is not controllable.')
end
if rank_Mo == size(A, 1)
    disp('System is observable.')
else
    disp('System is not observable.')
end
disp('----------------------------------------------');

t = linspace(0, 10, 100);
u = ones(size(t));
sys = ss(A, B, C, D);
[y, t] = lsim(sys, u, t);
fig2 = figure;
plot(t, y)
xlabel('Time')
ylabel('Output')
title('Open-Loop Step Response')
caption2 = 'Figure 2: Open-Loop Step Response using lsim';
annotation('textbox', [0.1,0.01,0.8,0.05], 'String', caption2, 'FitBoxToText', 'on', 'HorizontalAlignment', 'center');
saveas(gcf, 'Figure2_OpenLoop_lsim.png');
disp('----------------------------------------------');

sys_cl = feedback(sys, 1);
[y_cl, t] = lsim(sys_cl, u, t);
fig3 = figure;
plot(t, y_cl)
xlabel('Time')
ylabel('Output')
title('Closed-Loop Step Response')
poles_cl = pole(sys_cl);
Zeros_cl = zero(sys_cl);
disp('Closed-Loop State-Space:')
ss(sys_cl)
disp('Closed-Loop Poles:')
disp(poles_cl)
disp('Closed-Loop Zeros:')
disp(Zeros_cl)
caption3 = 'Figure 3: Closed-Loop Step Response';
annotation('textbox', [0.1,0.01,0.8,0.05], 'String', caption3, 'FitBoxToText', 'on', 'HorizontalAlignment', 'center');
saveas(gcf, 'Figure3_ClosedLoop_StepResponse.png');
disp('----------------------------------------------');

poles_desired = [-5+5i, -5-5i, -10];
K = place(A, B, poles_desired);
sys_cl = ss(A-B*K, B, C, D);
disp('State Feedback State-Space (Desired Poles):');
ss(sys_cl)
t = linspace(0, 5, 100);
u = ones(size(t));
[y_cl, t] = lsim(sys_cl, u, t);
x = lsim(sys_cl, u, t, [0; 0; 0]);
control_signal = -K .* x;
fig4 = figure;
subplot(3,1,1);
plot(t, y_cl);
xlabel('Time');
ylabel('Output');
title('Step Response');
subplot(3,1,2);
plot(t, x);
xlabel('Time');
ylabel('State Variables');
title('State Variables');
subplot(3,1,3);
plot(t, control_signal);
xlabel('Time');
ylabel('Control Signal');
title('Control Signal');
poles_ol = pole(sys);
Zeros_ol = zero(sys);
poles_cl = pole(sys_cl);
Zeros_cl = zero(sys_cl);
disp('Open-Loop Poles:');
disp(poles_ol);
disp('Open-Loop Zeros:');
disp(Zeros_ol);
disp('Desired Closed-Loop Poles:');
disp(poles_cl);
disp('Desired Closed-Loop Zeros:');
disp(Zeros_cl);
caption4 = 'Figure 4: State Feedback with Desired Poles (-5±5i, -10)';
annotation('textbox', [0.1,0.01,0.8,0.05], 'String', caption4, 'FitBoxToText', 'on', 'HorizontalAlignment', 'center');
saveas(gcf, 'Figure4_StateFeedback_DesiredPoles.png');
disp('---------------State Feedback (Further Poles)--------------');
poles_desired_far = [-15+15i, -15-15i, -25];
K_far = place(A, B, poles_desired_far);
sys_cl_far = ss(A-B*K_far, B, C, D);
disp('State Feedback State-Space (Further Poles):');
ss(sys_cl_far)
t = linspace(0, 5, 100);
u = ones(size(t));
[y_cl_far, t] = lsim(sys_cl_far, u, t);
x_far = lsim(sys_cl_far, u, t, [0; 0; 0]);
control_signal_far = -K_far .* x_far;
fig5 = figure;
subplot(3,1,1);
plot(t, y_cl_far);
xlabel('Time');
ylabel('Output');
title('Step Response (Further Poles)');
subplot(3,1,2);
plot(t, x_far);
xlabel('Time');
ylabel('State Variables');
title('State Variables (Further Poles)');
subplot(3,1,3);
plot(t, control_signal_far);
xlabel('Time');
ylabel('Control Signal');
title('Control Signal (Further Poles)');
poles_cl_far = pole(sys_cl_far);
Zeros_cl_far = zero(sys_cl_far);
disp('Closed-Loop Poles (Further Poles):');
disp(poles_cl_far);
disp('Closed-Loop Zeros (Further Poles):');
disp(Zeros_cl_far);
caption5 = 'Figure 5: State Feedback with Further Poles (-15±15i, -25)';
annotation('textbox', [0.1,0.01,0.8,0.05], 'String', caption5, 'FitBoxToText', 'on', 'HorizontalAlignment', 'center');
saveas(gcf, 'Figure5_StateFeedback_FurtherPoles.png');
disp('----------------------------------------------');

Nbar_far = (C*inv(A-B*K_far)*B)^-1;
sys_cl_static_far = ss(A-B*K_far, B*Nbar_far, C, D);
disp('Static Tracker State-Space (Further Poles):');
ss(sys_cl_static_far)
[y_cl_static_far, t] = lsim(sys_cl_static_far, u, t);
fig6 = figure;
plot(t, y_cl_static_far);
xlabel('Time');
ylabel('Output');
title('Step Response (Static Tracker, Further Poles)')
caption6 = 'Figure 6: Step Response with Static Tracker (Further Poles)';
annotation('textbox', [0.1,0.01,0.8,0.05], 'String', caption6, 'FitBoxToText', 'on', 'HorizontalAlignment', 'center');
saveas(gcf, 'Figure6_StaticTracker_FurtherPoles.png');
disp('----------------------------------------------');

Nbar = (C*inv(A-B*K)*B)^-1;
sys_cl_static = ss(A-B*K, B*Nbar, C, D);
disp('Static Tracker State-Space (Desired Poles):');
ss(sys_cl_static)
[y_cl_static, t] = lsim(sys_cl_static, u, t);
fig7 = figure;
plot(t, y_cl_static);
xlabel('Time');
ylabel('Output');
title('Step Response (Static Tracker, Desired Poles)')
caption7 = 'Figure 7: Step Response with Static Tracker (Desired Poles)';
annotation('textbox', [0.1,0.01,0.8,0.05], 'String', caption7, 'FitBoxToText', 'on', 'HorizontalAlignment', 'center');
saveas(gcf, 'Figure7_StaticTracker_DesiredPoles.png');
disp('----------------------------------------------');

A_aug = [A-B*K, zeros(size(A,1),1); -C, 0];
B_aug = [B; 0];
K_aug = place(A_aug, B_aug, [-5+5i, -5-5i, -10, -20]);
Ki = K_aug(end);
K = K_aug(1:end-1);
sys_cl_integral = ss(A-B*K, B, C, D);
disp('Integral Tracker State-Space:');
ss(sys_cl_integral)
[y_cl_integral, t] = lsim(sys_cl_integral, u, t);
fig8 = figure;
plot(t, y_cl_integral);
xlabel('Time');
ylabel('Output');
title('Step Response (Integral Tracker)')
caption8 = 'Figure 8: Step Response with Integral Tracker';
annotation('textbox', [0.1,0.01,0.8,0.05], 'String', caption8, 'FitBoxToText', 'on', 'HorizontalAlignment', 'center');
saveas(gcf, 'Figure8_IntegralTracker.png');
disp('----------------------------------------------');

fig9 = figure;
plot(t, y_cl, t, y_cl_static, t, y_cl_integral);
xlabel('Time');
ylabel('Output');
title('Closed-Loop Response Comparison')
legend('No Tracker', 'Static Tracker', 'Integral Tracker');
caption9 = 'Figure 9: Comparison of Closed-Loop Responses';
annotation('textbox', [0.1,0.01,0.8,0.05], 'String', caption9, 'FitBoxToText', 'on', 'HorizontalAlignment', 'center');
saveas(gcf, 'Figure9_Comparison.png');
disp('----------------------------------------------');

num = [6 18];
den = [1 3 -13.75 -31.5];
T = tf(num, den);
[A, B, C, D] = tf2ss(num, den);
poles_desired = [-5+5i, -5-5i, -10];
disp('Original A matrix:'); disp(A);
K = place(A, B, poles_desired); % استفاده از 'place' برای محاسبه K


T_sim_observer_feedback_original = 5;
t_sim_observer_feedback_original = linspace(0, T_sim_observer_feedback_original, 500);
r_observer_feedback_original = ones(size(t_sim_observer_feedback_original));
x0_observer_feedback_original = [1; -1; 0.5];
x_hat0_observer_feedback_original = [0; 0; 0];

% برای شبیه سازی observer-based feedback، به L نیاز داریم.  L را بر اساس قطب های observer طراحی کنید.
poles_observer_desired_fast = [-20, -21, -22]; % قطب های observer را سریعتر انتخاب کنید
L_fast = place(A', C', poles_observer_desired_fast)'; % توجه کنید به ترانهاده ها


x_obs_fb_original = zeros(3, length(t_sim_observer_feedback_original));
x_hat_obs_fb_original = zeros(3, length(t_sim_observer_feedback_original));
y_obs_fb_original = zeros(size(C,1), length(t_sim_observer_feedback_original));
y_measured_obs_fb_original = zeros(size(C,1), length(t_sim_observer_feedback_original));
u_obs_fb_original = zeros(size(B,2), length(t_sim_observer_feedback_original));


x_obs_fb_original(:,1) = x0_observer_feedback_original;
x_hat_obs_fb_original(:,1) = x_hat0_observer_feedback_original;
y_obs_fb_original(:,1) = C*x_obs_fb_original(:,1) + D*r_observer_feedback_original(1);
y_measured_obs_fb_original(:,1) = C*x_obs_fb_original(:,1) + D*r_observer_feedback_original(1);


for i = 1:length(t_sim_observer_feedback_original)-1
    dt = t_sim_observer_feedback_original(i+1) - t_sim_observer_feedback_original(i);

    u_obs_fb_original(:,i) = -K * x_hat_obs_fb_original(:,i);

    x_dot_obs_fb_original = A*x_obs_fb_original(:,i) + B*u_obs_fb_original(:,i);
    x_obs_fb_original(:,i+1) = x_obs_fb_original(:,i) + x_dot_obs_fb_original * dt;
    y_obs_fb_original(:,i+1) = C*x_obs_fb_original(:,i+1) + D*r_observer_feedback_original(i+1);
    y_measured_obs_fb_original(:,i+1) = C*x_obs_fb_original(:,i+1) + D*r_observer_feedback_original(i+1);

    x_hat_dot_obs_fb_original = A*x_hat_obs_fb_original(:,i) + B*u_obs_fb_original(:,i) + L_fast*(y_measured_obs_fb_original(:,i+1) - C*x_hat_obs_fb_original(:,i));
    x_hat_obs_fb_original(:,i+1) = x_hat_obs_fb_original(:,i) + x_hat_dot_obs_fb_original * dt;


end



estimation_error_obs_fb_original = x_obs_fb_original - x_hat_obs_fb_original;


figure('Name', 'State and Estimation Error Plots'); % نام برای پنجره فیگور
sgtitle('State and Estimation Error Plots'); % کپشن برای کل فیگور

subplot(3, 2, 1);
plot(t_sim_observer_feedback_original, x_obs_fb_original(1,:), 'b-', t_sim_observer_feedback_original, x_hat_obs_fb_original(1,:), 'r--');
xlabel('Time'); ylabel('x_1, x_1_{hat}'); title('State x_1'); legend('Actual x_1', 'Estimated x_1');
subplot(3, 2, 3);
plot(t_sim_observer_feedback_original, x_obs_fb_original(2,:), 'b-', t_sim_observer_feedback_original, x_hat_obs_fb_original(2,:), 'r--');
xlabel('Time'); ylabel('x_2, x_2_{hat}'); title('State x_2'); legend('Actual x_2', 'Estimated x_2');
subplot(3, 2, 5);
plot(t_sim_observer_feedback_original, x_obs_fb_original(3,:), 'b-', t_sim_observer_feedback_original, x_hat_obs_fb_original(3,:), 'r--');
xlabel('Time'); ylabel('x_3, x_3_{hat}'); title('State x_3'); legend('Actual x_3', 'Estimated x_3');



subplot(3, 2, 2);
plot(t_sim_observer_feedback_original, estimation_error_obs_fb_original(1,:));
xlabel('Time'); ylabel('e_1'); title('Error e_1');
subplot(3, 2, 4);
plot(t_sim_observer_feedback_original, estimation_error_obs_fb_original(2,:));
xlabel('Time'); ylabel('e_2'); title('Error e_2');
subplot(3, 2, 6);
plot(t_sim_observer_feedback_original, estimation_error_obs_fb_original(3,:));
xlabel('Time'); ylabel('e_3'); title('Error e_3');

saveas(gcf, 'state_estimation_error_plots.png'); % ذخیره فیگور با نام و فرمت png


figure('Name', 'Output and Control Signal Plots'); % نام برای پنجره فیگور
sgtitle('Output and Control Signal Plots'); % کپشن برای کل فیگور

subplot(2, 1, 1);
plot(t_sim_observer_feedback_original, y_obs_fb_original);
xlabel('Time'); ylabel('Output y'); title('Output Response');

subplot(2, 1, 2);
plot(t_sim_observer_feedback_original, u_obs_fb_original);
xlabel('Time'); ylabel('Control u'); title('Control Signal');

saveas(gcf, 'output_control_plots.png'); % ذخیره فیگور با نام و فرمت png



step_info_original_fb = stepinfo(ss(A - B*K, B, C, D));

disp('Step Response Characteristics Analysis');
disp('Step Response Plots Generated');
disp('Ideal Full State Feedback (Benchmark)');
disp(['Overshoot (benchmark): ', num2str(step_info_original_fb.Overshoot), '%']);
disp(['Settling Time (benchmark): ', num2str(step_info_original_fb.SettlingTime), ' seconds']);
disp('Observe Plots for: Output, States, Errors, Control');
disp('Visually assess: Overshoot, Settling Time, Steady State Error, Control Effort smoothness');
disp('Compare with benchmark full state feedback.');
disp('Note: For precise stepinfo analysis, derive augmented closed loop model.');
disp('Focus on visual assessment for initial analysis.');

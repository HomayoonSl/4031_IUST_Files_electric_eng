%% Reduced Observer-Based Tracker Design (ORIGINAL System)

%% Simulation: Reduced Observer-Based Tracker (ORIGINAL System)
T_sim_reduced_tracker = 5;
t_sim_reduced_tracker = linspace(0, T_sim_reduced_tracker, 500);
r_reduced_tracker = ones(size(t_sim_reduced_tracker));
x0_reduced_tracker = [1; -1; 0.5];
x_r_hat0_fast_reduced_tracker = [0; 0];

% Simulation Loop
x_reduced_tracker = zeros(3, length(t_sim_reduced_tracker));
x_r_hat_fast_reduced_tracker = zeros(2, length(t_sim_reduced_tracker));
x_hat_reduced_full_tracker = zeros(3, length(t_sim_reduced_tracker));
y_reduced_tracker = zeros(size(C,1), length(t_sim_reduced_tracker));
y_measured_reduced_tracker = zeros(size(C,1), length(t_sim_reduced_tracker));

u_reduced_tracker_static_N = zeros(size(B,2), length(t_sim_reduced_tracker));
u_reduced_tracker_integrator= zeros(size(B,2), length(t_sim_reduced_tracker));

x_int_reduced_tracker = 0 ;

x_reduced_tracker(:,1) = x0_reduced_tracker;
x_r_hat_fast_reduced_tracker(:,1) = x_r_hat0_fast_reduced_tracker;
y_reduced_tracker(:,1) = C*x_reduced_tracker(:,1) + D*r_reduced_tracker(1);
y_measured_reduced_tracker(:,1) = C*x_reduced_tracker(:,1) + D*r_reduced_tracker(1);
x_hat_reduced_full_tracker(:,1) = [x_r_hat_fast_reduced_tracker(:,1); 0];

for i = 1:length(t_sim_reduced_tracker)-1
    dt = t_sim_reduced_tracker(i+1) - t_sim_reduced_tracker(i);

    % Control Law
   Nbar = (C*inv(A - B*K)*B)^-1;

    %Static scaling set point control
  u_reduced_tracker_static_N(:,i) = -K * x_hat_reduced_full_tracker(:,i) + Nbar * r_reduced_tracker(i) ;

    % Integrator error tracking
     ki = 1;
     error = r_reduced_tracker(i) - C*x_reduced_tracker(:,i);
    u_reduced_tracker_integrator(:,i) = -K * x_hat_reduced_full_tracker(:,i) + ki*x_int_reduced_tracker ;
   x_int_dot_reduced = error ;
    x_int_reduced_tracker = x_int_reduced_tracker + x_int_dot_reduced*dt;


    % ORIGINAL System Update
    x_dot_reduced_tracker = A*x_reduced_tracker(:,i) + B*u_reduced_tracker_integrator(:,i);
    x_reduced_tracker(:,i+1) = x_reduced_tracker(:,i) + x_dot_reduced_tracker * dt;
    y_reduced_tracker(:,i+1) = C*x_reduced_tracker(:,i+1) + D*r_reduced_tracker(i+1);
     y_measured_reduced_tracker(:,i+1) = C*x_reduced_tracker(:,i+1) + D*r_reduced_tracker(i+1);


    % Naive Reduced Observer Update
   x_r_hat_dot_fast_reduced_tracker = Ar_reduced * x_r_hat_fast_reduced_tracker(:,i) + Br_reduced * u_reduced_tracker_integrator(:,i) + L_reduced_fast_naive*(y_measured_reduced_tracker(:,i+1) - Cr_reduced_projected * x_r_hat_fast_reduced_tracker(:,i));
    x_r_hat_fast_reduced_tracker(:,i+1) = x_r_hat_fast_reduced_tracker(:,i) + x_r_hat_dot_fast_reduced_tracker * dt;
    x_hat_reduced_full_tracker(1:2, i+1) = x_r_hat_fast_reduced_tracker(:,i+1) ;
    x_hat_reduced_full_tracker(3, i+1) = 0;

end

%% Plotting Results: Reduced Observer-Based Tracker (ORIGINAL System)
estimation_error_reduced_tracker = x_reduced_tracker - x_hat_reduced_full_tracker;

% Create a folder to save figures if it doesn't exist
if ~exist('figures', 'dir')
    mkdir('figures');
end

figure_counter = 1;

% Figure 1: State Variables and Estimation Errors (Static N)
figure(figure_counter);

% State Variables (Static N)
subplot(3, 2, 1);
plot(t_sim_reduced_tracker, x_reduced_tracker(1,:), 'b-', t_sim_reduced_tracker, x_hat_reduced_full_tracker(1,:), 'r--');
xlabel('Time'); ylabel('x_1, x_1_{hat}'); title('ORIG Sys  Tracker St. N x1 w reduced Obs output.'); legend('Actual x_1', 'Est x_1 (Red Observer)');
subplot(3, 2, 3);
plot(t_sim_reduced_tracker, x_reduced_tracker(2,:), 'b-', t_sim_reduced_tracker, x_hat_reduced_full_tracker(2,:), 'r--');
xlabel('Time'); ylabel('x_2, x_2_{hat}'); title('ORIG Sys Tracker St.N x2 w reduced Obs output.'); legend('Actual x_2', 'Est x_2 (Red Observer)');
subplot(3, 2, 5);
plot(t_sim_reduced_tracker, x_reduced_tracker(3,:), 'b-', t_sim_reduced_tracker, x_hat_reduced_full_tracker(3,:), 'r--');
xlabel('Time'); ylabel('x_3, x_3_{hat}'); title('ORIG Sys  Tracker  St.N x3  (forced zero via simplified Reduced Obs)'); legend('Actual x_3', 'Est x_3 = Forced 0 Red Observer');

% Estimation Errors (Static N)
subplot(3, 2, 2);
plot(t_sim_reduced_tracker, estimation_error_reduced_tracker(1,:));
xlabel('Time'); ylabel('e_1'); title('Estimation Err e_1: Tracker+ (Static  Nbar) ');
subplot(3, 2, 4);
plot(t_sim_reduced_tracker, estimation_error_reduced_tracker(2,:));
xlabel('Time'); ylabel('e_2'); title('Estimation Err e_2: Tracker + (Static Nbar)');
subplot(3, 2, 6);
plot(t_sim_reduced_tracker, estimation_error_reduced_tracker(3,:));
xlabel('Time'); ylabel('e_3'); title('Estimation Err e_3: Tracker (Static  Nbar ) ');

% Save Figure 1 with caption
figure1_filename = fullfile('figures', 'Figure1_State_Estimation_StaticN.fig');
savefig(gcf, figure1_filename);


figure_counter = figure_counter + 1;
% Figure 2: Output Response and Control Input
figure(figure_counter);  % New Figure

% Output Response y (Static Nbar)
subplot(2, 2, 1);
plot(t_sim_reduced_tracker, y_reduced_tracker);
xlabel('Time'); ylabel('Output y'); title('ORIG Sys Output Response, Static compensation (Nbar)');

% Control u (Static Nbar)
subplot(2, 2, 2);
plot(t_sim_reduced_tracker, u_reduced_tracker_static_N);
xlabel('Time'); ylabel('Control u static_N'); title('Control u w/static feedback comp from est state');


% Output Response y (Integrator)
subplot(2, 2, 3);
plot(t_sim_reduced_tracker, y_reduced_tracker);
xlabel('Time'); ylabel('Output y '); title('ORIG Sys Output Resp (Integrator Comp)');

% Control u (Integrator)
subplot(2, 2, 4);
plot(t_sim_reduced_tracker, u_reduced_tracker_integrator);
xlabel('Time'); ylabel('Control u (integrator tracking)'); title('Control w Integral action & Obs Red (Naive)')

% Save Figure 2 with caption
figure2_filename = fullfile('figures', 'Figure2_Output_Control_StaticN_Integrator.fig');
savefig(gcf, figure2_filename);


%% Output Trajectory Analysis

disp('--- Reduced Observer-Based Tracker System Analysis - Original Plant setup');
disp('Reduced Order Observer output used with Tracker  using - feed-forward (Nbar Gain) , versus,');
disp(' Tracker+  using also output integral based compensator from integral errors as control action ');
disp('Tracker implementations: By using estimated state vector that drives control, to force `y` go to specific set-point via different methods.');
disp('Look into state, tracking  errors as in plots for interpretations.');
disp('  Observe transient responses, overshoots, tracking speeds for two control method set-ups');
disp(' Note: Performance degradation here is due to simplified *naive approach for 2nd Order Reduced Observer*');



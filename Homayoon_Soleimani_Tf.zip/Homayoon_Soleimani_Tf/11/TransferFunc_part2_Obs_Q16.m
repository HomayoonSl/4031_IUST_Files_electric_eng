%% Observer-Based State Feedback Tracker Design

%% Simulation of Observer-Based State Feedback Tracker

T_sim_tracker = 5;
t_sim_tracker = linspace(0, T_sim_tracker, 500);
r_tracker = ones(size(t_sim_tracker));
x0_tracker = [1; -1; 0.5];
x_hat0_tracker = [0; 0; 0];

x_tracker = zeros(3, length(t_sim_tracker));
x_hat_tracker = zeros(3, length(t_sim_tracker));
y_tracker = zeros(size(C,1), length(t_sim_tracker));
y_measured_tracker = zeros(size(C,1), length(t_sim_tracker));
u_tracker_static_N = zeros(size(B,2), length(t_sim_tracker));
u_tracker_integrator = zeros(size(B,2), length(t_sim_tracker));

x_int = 0;

x_tracker(:,1) = x0_tracker;
x_hat_tracker(:,1) = x_hat0_tracker;
y_tracker(:,1) = C*x_tracker(:,1) + D*r_tracker(1);
y_measured_tracker(:,1) = C*x_tracker(:,1) + D*r_tracker(1);

for i = 1:length(t_sim_tracker)-1
    dt = t_sim_tracker(i+1) - t_sim_tracker(i);

    Nbar = (C*inv(A - B*K)*B)^-1;
    u_tracker_static_N(:,i) = -K * x_hat_tracker(:,i) + Nbar*r_tracker(i) ;

    ki = 1;
     error = r_tracker(i) - C*x_tracker(:,i)  ;
    u_tracker_integrator(:,i) = -K * x_hat_tracker(:,i)  +  ki* x_int  ;
   x_int_dot  = error;
    x_int = x_int + x_int_dot * dt ;


    x_dot_tracker = A*x_tracker(:,i) + B*u_tracker_integrator(:,i);
    x_tracker(:,i+1) = x_tracker(:,i) + x_dot_tracker * dt;
    y_tracker(:,i+1) = C*x_tracker(:,i+1) + D*r_tracker(i+1);
    y_measured_tracker(:,i+1) = C*x_tracker(:,i+1) + D*r_tracker(i+1);


    x_hat_dot_tracker = A*x_hat_tracker(:,i) + B*u_tracker_integrator(:,i) + L_fast*(y_measured_tracker(:,i+1) - C*x_hat_tracker(:,i));

    x_hat_tracker(:,i+1) = x_hat_tracker(:,i) + x_hat_dot_tracker * dt;


end


%% Plotting Results
estimation_error_tracker = x_tracker - x_hat_tracker;


figure('Name', 'State and Estimation Errors (Nbar)'); % نام برای شکل
subplot(3, 2, 1);
plot(t_sim_tracker, x_tracker(1,:), 'b-', t_sim_tracker, x_hat_tracker(1,:), 'r--');
xlabel('Time'); ylabel('x_1, x_1_{hat}'); title('State x1 (Nbar)'); legend('Actual x_1', 'Estimated x_1');
subplot(3, 2, 3);
plot(t_sim_tracker, x_tracker(2,:), 'b-', t_sim_tracker, x_hat_tracker(2,:), 'r--');
xlabel('Time'); ylabel('x_2, x_2_{hat}'); title('State x2 (Nbar)'); legend('Actual x_2', 'Estimated x_2');
subplot(3, 2, 5);
plot(t_sim_tracker, x_tracker(3,:), 'b-', t_sim_tracker, x_hat_tracker(3,:), 'r--');
xlabel('Time'); ylabel('x_3, x_3_{hat}'); title('State x3 (Nbar)'); legend('Actual x_3', 'Estimated x_3');


subplot(3, 2, 2);
plot(t_sim_tracker, estimation_error_tracker(1,:));
xlabel('Time'); ylabel('e_1'); title('Error e_1 (Nbar)');
subplot(3, 2, 4);
plot(t_sim_tracker, estimation_error_tracker(2,:));
xlabel('Time'); ylabel('e_2'); title('Error e_2 (Nbar)');
subplot(3, 2, 6);
plot(t_sim_tracker, estimation_error_tracker(3,:));
xlabel('Time'); ylabel('e_3'); title('Error e_3 (Nbar)');

% اضافه کردن کپشن برای شکل اول
annotation('textbox', [0,0,1,0.05], 'String', 'Figure 1: State x and Estimated State x_hat with Estimation Errors (Nbar)', 'HorizontalAlignment','center', 'FitBoxToText','on');

% ذخیره شکل اول با کپشن
saveas(gcf,'Figure_1_State_Estimation_Errors_Nbar.png') % ذخیره به فرمت png
savefig('Figure_1_State_Estimation_Errors_Nbar.fig')   % ذخیره به فرمت fig (قابل ویرایش در متلب)


figure('Name', 'Output and Control Signals'); % نام برای شکل دوم
subplot(2, 2, 1);
plot(t_sim_tracker, y_tracker);
xlabel('Time'); ylabel('Output y'); title('Output y (Nbar)');


subplot(2, 2, 2);
plot(t_sim_tracker, u_tracker_static_N);
xlabel('Time'); ylabel('Control u static_N(t)'); title('Control u (Nbar)');


subplot(2, 2, 3);
plot(t_sim_tracker, y_tracker);
xlabel('Time'); ylabel('Output y(t)'); title('Output y (Integrator)');


subplot(2, 2, 4);
plot(t_sim_tracker, u_tracker_integrator);
xlabel('Time'); ylabel('Control u Integrator-Feedback Comp (Time based tracker method )'); title('Control u (Integrator)');

% اضافه کردن کپشن برای شکل دوم
annotation('textbox', [0,0,1,0.05], 'String', 'Figure 2: Output and Control Signals (Nbar and Integrator)', 'HorizontalAlignment','center', 'FitBoxToText','on');

% ذخیره شکل دوم با کپشن
saveas(gcf,'Figure_2_Output_Control_Signals.png') % ذخیره به فرمت png
savefig('Figure_2_Output_Control_Signals.fig')   % ذخیره به فرمت fig (قابل ویرایش در متلب)



%% Analysis of Tracker System Step Response
disp(' ');
disp('--- Tracker System Simulation Analysis ---')
disp(' ')
disp('Tracker with static gain feedforward:')
disp('Observe graphs from those above sections.')

disp('Observer + State tracker (static feedforward):')
disp('  -> Expect settling to ref target (r), after certain period, where output deviation and tracking errors are zero from state values, when observer values have already converged properly')


disp('Integrator tracker (Observer + Integrator + State feedback):')

disp('Expect : settling to r, output= ref (r=1) after certain period but not always perfectly following a path at fast rates as integrator are known to act slower especially with higher state dimensions)')

disp('Compare for performance such as : output reach zero error from state (if state value at output = setpoint or any value desired ) in given settling/converging times, compare oscillations and all the control, estimation responses  during settling of this tracker, ')
disp('and also see transient error behaviors ')


disp(' Note both static gain method and an integrator approach to a tracking setpoint has certain merits or demerits. Check and compare these based on transient overshoot/ settling rates at step change set point input');
disp('Compare with those previously achieved results from simulations')

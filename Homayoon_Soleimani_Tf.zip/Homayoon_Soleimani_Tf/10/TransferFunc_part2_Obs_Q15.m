%% Reduced Observer State Feedback for Original System (Naive)

T_sim_reduced_observer_fb_original = 5;
t_sim_reduced_observer_fb_original = linspace(0, T_sim_reduced_observer_fb_original, 500);
r_reduced_observer_fb_original = ones(size(t_sim_reduced_observer_fb_original));
x0_reduced_observer_fb_original = [1; -1; 0.5];
x_r_hat0_fast_reduced_observer_fb_original = [0; 0];

x_reduced_obs_fb_original = zeros(3, length(t_sim_reduced_observer_fb_original));
x_r_hat_fast_reduced_obs_fb_original = zeros(2, length(t_sim_reduced_observer_fb_original));
x_hat_reduced_full_obs_fb_original = zeros(3, length(t_sim_reduced_observer_fb_original));
y_reduced_obs_fb_original = zeros(size(C,1), length(t_sim_reduced_observer_fb_original));
y_measured_reduced_obs_fb_original = zeros(size(C,1), length(t_sim_reduced_observer_fb_original));
u_reduced_obs_fb_original = zeros(size(B,2), length(t_sim_reduced_observer_fb_original));

x_reduced_obs_fb_original(:,1) = x0_reduced_observer_fb_original;
x_r_hat_fast_reduced_obs_fb_original(:,1) = x_r_hat0_fast_reduced_observer_fb_original;
y_reduced_obs_fb_original(:,1) = C*x_reduced_obs_fb_original(:,1) + D*r_reduced_observer_fb_original(1);
y_measured_reduced_obs_fb_original(:,1) = C*x_reduced_obs_fb_original(:,1) + D*r_reduced_observer_fb_original(1);
x_hat_reduced_full_obs_fb_original(:,1) = [x_r_hat_fast_reduced_obs_fb_original(:,1); 0];

for i = 1:length(t_sim_reduced_observer_fb_original)-1
    dt = t_sim_reduced_observer_fb_original(i+1) - t_sim_reduced_observer_fb_original(i);

    x_hat_control_reduced_naive_original = [x_r_hat_fast_reduced_obs_fb_original(:,i); 0];
    u_reduced_obs_fb_original(:,i) = -K * x_hat_control_reduced_naive_original;

    x_dot_reduced_obs_fb_original = A*x_reduced_obs_fb_original(:,i) + B*u_reduced_obs_fb_original(:,i);
    x_reduced_obs_fb_original(:,i+1) = x_reduced_obs_fb_original(:,i) + x_dot_reduced_obs_fb_original * dt;
    y_reduced_obs_fb_original(:,i+1) = C*x_reduced_obs_fb_original(:,i+1) + D*r_reduced_observer_fb_original(i+1);
    y_measured_reduced_obs_fb_original(:,i+1) = C*x_reduced_obs_fb_original(:,i+1) + D*r_reduced_observer_fb_original(i+1);

    x_r_hat_dot_fast_reduced_obs_fb_original = Ar_reduced * x_r_hat_fast_reduced_obs_fb_original(:,i) + Br_reduced * u_reduced_obs_fb_original(:,i) + L_reduced_fast_naive*(y_measured_reduced_obs_fb_original(:,i+1) - Cr_reduced_projected * x_r_hat_fast_reduced_obs_fb_original(:,i));
    x_r_hat_fast_reduced_obs_fb_original(:,i+1) = x_r_hat_fast_reduced_obs_fb_original(:,i+1) + x_r_hat_dot_fast_reduced_obs_fb_original * dt;
    x_hat_reduced_full_obs_fb_original(1:2, i+1) = x_r_hat_fast_reduced_obs_fb_original(:, i+1);
    x_hat_reduced_full_obs_fb_original(3, i+1) = 0;
end


%% Plotting Results (Naive Reduced Observer)

estimation_error_reduced_obs_fb_original_naive = x_reduced_obs_fb_original - x_hat_reduced_full_obs_fb_original;

figure('Name', 'State Estimation and Errors (Naive Reduced Observer)'); % عنوان فیگور اضافه شد

subplot(3, 2, 1);
plot(t_sim_reduced_observer_fb_original, x_reduced_obs_fb_original(1,:), 'b-', t_sim_reduced_observer_fb_original, x_hat_reduced_full_obs_fb_original(1,:), 'r--');
xlabel('Time'); ylabel('x_1, x_{1,hat}'); title('State x_1 (Naive Reduced Obs)'); legend('Actual', 'Estimated');
subplot(3, 2, 3);
plot(t_sim_reduced_observer_fb_original, x_reduced_obs_fb_original(2,:), 'b-', t_sim_reduced_observer_fb_original, x_hat_reduced_full_obs_fb_original(2,:), 'r--');
xlabel('Time'); ylabel('x_2, x_{2,hat}'); title('State x_2 (Naive Reduced Obs)'); legend('Actual', 'Estimated');
subplot(3, 2, 5);
plot(t_sim_reduced_observer_fb_original, x_reduced_obs_fb_original(3,:), 'b-', t_sim_reduced_observer_fb_original, x_hat_reduced_full_obs_fb_original(3,:), 'r--');
xlabel('Time'); ylabel('x_3, x_{3,hat}'); title('State x_3 (Naive Reduced Obs)'); legend('Actual', 'Estimated');

subplot(3, 2, 2);
plot(t_sim_reduced_observer_fb_original, estimation_error_reduced_obs_fb_original_naive(1,:));
xlabel('Time'); ylabel('e_1'); title('Error e_1 (Naive Reduced Obs)');
subplot(3, 2, 4);
plot(t_sim_reduced_observer_fb_original, estimation_error_reduced_obs_fb_original_naive(2,:));
xlabel('Time'); ylabel('e_2'); title('Error e_2 (Naive Reduced Obs)');
subplot(3, 2, 6);
plot(t_sim_reduced_observer_fb_original, estimation_error_reduced_obs_fb_original_naive(3,:));
xlabel('Time'); ylabel('e_3'); title('Error e_3 (Naive Reduced Obs)');

% ذخیره فیگور اول
fig1 = gcf;
fig1_title = get(fig1, 'Name');
if isempty(fig1_title)
    filename_fig1 = 'figure_state_estimation_errors_naive_reduced_observer';
else
    filename_fig1 = strrep(fig1_title, ' ', '_'); % جایگزینی فاصله با زیرخط برای نام فایل
end
saveas(fig1, filename_fig1, 'png'); % ذخیره به فرمت PNG
saveas(fig1, filename_fig1, 'fig'); % ذخیره به فرمت FIG (فایل متلب)


figure('Name', 'Output and Control Response (Naive Reduced Observer)'); % عنوان فیگور اضافه شد

subplot(2, 1, 1);
plot(t_sim_reduced_observer_fb_original, y_reduced_obs_fb_original);
xlabel('Time'); ylabel('Output y'); title('Output Response (Naive)');

subplot(2, 1, 2);
plot(t_sim_reduced_observer_fb_original, u_reduced_obs_fb_original);
xlabel('Time'); ylabel('Control u'); title('Control Signal (Naive)');

% ذخیره فیگور دوم
fig2 = gcf;
fig2_title = get(fig2, 'Name');
if isempty(fig2_title)
    filename_fig2 = 'figure_output_control_response_naive_reduced_observer';
else
    filename_fig2 = strrep(fig2_title, ' ', '_'); % جایگزینی فاصله با زیرخط برای نام فایل
end
saveas(fig2, filename_fig2, 'png'); % ذخیره به فرمت PNG
saveas(fig2, filename_fig2, 'fig'); % ذخیره به فرمت FIG (فایل متلب)


%% Step Response Analysis (Naive Reduced Observer)

disp(' ');
disp('Step Response Analysis (Naive Reduced Observer)');
disp(' ');
disp('Step Response Plots Generated');
disp(' ');
disp('Observe plots: Output y, States x, Errors e, Control u');
disp('Assess: Overshoot, Settling Time, Steady State Error, Control Effort');
disp('Compare with full state feedback and full order observer results.');
disp(' ');
disp('Note: Performance is limited by Naive Reduced Observer.');
disp('For better performance, rigorous Reduced Order Observer is needed.');
disp(' ');

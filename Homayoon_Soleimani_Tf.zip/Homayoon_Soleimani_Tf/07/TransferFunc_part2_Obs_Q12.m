num = [6 18];
den = [1 3 -13.75 -31.5];
T = tf(num, den);
[A, B, C, D] = tf2ss(num, den);
poles_desired = [-5+5i, -5-5i, -10];

% Assuming K and L_slow, L_fast are already defined or calculated elsewhere in your complete code.
% For this example, let's define some placeholder values if they are missing.
% **Important:** Replace these with your actual K, L_slow, and L_fast values.
K = place(A, B, poles_desired); % Example K calculation if needed
observer_poles_slow = 10*poles_desired; % Example slow observer poles
L_slow = place(A', C', observer_poles_slow)'; % Example L_slow calculation
observer_poles_fast = 20*poles_desired; % Example fast observer poles
L_fast = place(A', C', observer_poles_fast)'; % Example L_fast calculation


A_modified = A;
A_modified(1, 2) = A_modified(1, 2) * 1.2;
disp('Original A matrix:'); disp(A);
disp('Modified A matrix:'); disp(A_modified);

sys_modified = ss(A_modified, B, C, D);

T_sim_modified = 5;
t_sim_modified = linspace(4, T_sim_modified, 500);
r_modified = ones(size(t_sim_modified));
x0_modified = [1; -1; 0.5];
x_hat0_slow_modified = [0; 0; 0];
x_hat0_fast_modified = [0; 0; 0];


x_modified_slow = zeros(3, length(t_sim_modified));
x_hat_slow_modified = zeros(3, length(t_sim_modified));
y_modified_slow = zeros(size(C,1), length(t_sim_modified));
y_measured_slow_modified = zeros(size(C,1), length(t_sim_modified));
u_slow_modified = zeros(size(B,2), length(t_sim_modified));

x_modified_slow(:,1) = x0_modified;
x_hat_slow_modified(:,1) = x_hat0_slow_modified;
y_modified_slow(:,1) = C*x_modified_slow(:,1) + D*r_modified(1);
y_measured_slow_modified(:,1) = C*x_modified_slow(:,1) + D*r_modified(1);


for i = 1:length(t_sim_modified)-1
    dt = t_sim_modified(i+1) - t_sim_modified(i);

    u_slow_modified(:,i) = -K * x_hat_slow_modified(:,i);

    x_dot_modified_slow = A_modified*x_modified_slow(:,i) + B*u_slow_modified(:,i);
    x_modified_slow(:,i+1) = x_modified_slow(:,i) + x_dot_modified_slow * dt;
    y_modified_slow(:,i+1) = C*x_modified_slow(:,i+1) + D*r_modified(i+1);
    y_measured_slow_modified(:,i+1) = C*x_modified_slow(:,i+1) + D*r_modified(i+1);

    x_hat_dot_slow_modified = A*x_hat_slow_modified(:,i) + B*u_slow_modified(:,i) + L_slow*(y_measured_slow_modified(:,i+1) - C*x_hat_slow_modified(:,i));
    x_hat_slow_modified(:,i+1) = x_hat_slow_modified(:,i) + x_hat_dot_slow_modified * dt;

end



x_modified_fast = zeros(3, length(t_sim_modified));
x_hat_fast_modified = zeros(3, length(t_sim_modified));
y_modified_fast = zeros(size(C,1), length(t_sim_modified));
y_measured_fast_modified = zeros(size(C,1), length(t_sim_modified));
u_fast_modified = zeros(size(B,2), length(t_sim_modified));

x_modified_fast(:,1) = x0_modified;
x_hat_fast_modified(:,1) = x_hat0_fast_modified;
y_modified_fast(:,1) = C*x_modified_fast(:,1) + D*r_modified(1);
y_measured_fast_modified(:,1) = C*x_modified_fast(:,1) + D*r_modified(1);

for i = 1:length(t_sim_modified)-1
    dt = t_sim_modified(i+1) - t_sim_modified(i);

    u_fast_modified(:,i) = -K * x_hat_fast_modified(:,i);

    x_dot_modified_fast = A_modified*x_modified_fast(:,i) + B*u_fast_modified(:,i);
    x_modified_fast(:,i+1) = x_modified_fast(:,i) + x_dot_modified_fast * dt;
    y_modified_fast(:,i+1) = C*x_modified_fast(:,i+1) + D*r_modified(i+1);
    y_measured_fast_modified(:,i+1) = C*x_modified_fast(:,i+1) + D*r_modified(i+1);

    x_hat_dot_fast_modified = A*x_hat_fast_modified(:,i) + B*u_fast_modified(:,i) + L_fast*(y_measured_fast_modified(:,i+1) - C*x_hat_fast_modified(:,i));
    x_hat_fast_modified(:,i+1) = x_hat_fast_modified(:,i) + x_hat_dot_fast_modified * dt;

end


estimation_error_slow_modified = x_modified_slow - x_hat_slow_modified;
estimation_error_fast_modified = x_modified_fast - x_hat_fast_modified;


figure_states = figure;

subplot(3, 2, 1);
plot(t_sim_modified, x_modified_slow(1,:), 'b-', t_sim_modified, x_hat_slow_modified(1,:), 'r--');
xlabel('Time'); ylabel('x_1, x_{hat1}'); title('x_1 States - Slow Observer'); legend('Actual', 'Estimated');
subplot(3, 2, 3);
plot(t_sim_modified, x_modified_slow(2,:), 'b-', t_sim_modified, x_hat_slow_modified(2,:), 'r--');
xlabel('Time'); ylabel('x_2, x_{hat2}'); title('x_2 States - Slow Observer'); legend('Actual', 'Estimated');
subplot(3, 2, 5);
plot(t_sim_modified, x_modified_slow(3,:), 'b-', t_sim_modified, x_hat_slow_modified(3,:), 'r--');
xlabel('Time'); ylabel('x_3, x_{hat3}'); title('x_3 States - Slow Observer'); legend('Actual', 'Estimated');


subplot(3, 2, 2);
plot(t_sim_modified, x_modified_fast(1,:), 'b-', t_sim_modified, x_hat_fast_modified(1,:), 'r--');
xlabel('Time'); ylabel('x_1, x_{hat1}'); title('x_1 States - Fast Observer'); legend('Actual', 'Estimated');
subplot(3, 2, 4);
plot(t_sim_modified, x_modified_fast(2,:), 'b-', t_sim_modified, x_hat_fast_modified(2,:), 'r--');
xlabel('Time'); ylabel('x_2, x_{hat2}'); title('x_2 States - Fast Observer'); legend('Actual', 'Estimated');
subplot(3, 2, 6);
plot(t_sim_modified, x_modified_fast(3,:), 'b-', t_sim_modified, x_hat_fast_modified(3,:), 'r--');
xlabel('Time'); ylabel('x_3, x_{hat3}'); title('x_3 States - Fast Observer'); legend('Actual', 'Estimated');

sgtitle(figure_states, 'State Estimation Performance Comparison: Slow vs. Fast Observers');
saveas(figure_states, 'State_Estimation_Comparison.png');


figure_errors = figure;

subplot(3, 2, 1);
plot(t_sim_modified, estimation_error_slow_modified(1,:));
xlabel('Time'); ylabel('e_1'); title('e_1 Error - Slow Observer');
subplot(3, 2, 3);
plot(t_sim_modified, estimation_error_slow_modified(2,:));
xlabel('Time'); ylabel('e_2'); title('e_2 Error - Slow Observer');
subplot(3, 2, 5);
plot(t_sim_modified, estimation_error_slow_modified(3,:));
xlabel('Time'); ylabel('e_3'); title('e_3 Error - Slow Observer');

subplot(3, 2, 2);
plot(t_sim_modified, estimation_error_fast_modified(1,:));
xlabel('Time'); ylabel('e_1'); title('e_1 Error - Fast Observer');
subplot(3, 2, 4);
plot(t_sim_modified, estimation_error_fast_modified(2,:));
xlabel('Time'); ylabel('e_2'); title('e_2 Error - Fast Observer');
subplot(3, 2, 6);
plot(t_sim_modified, estimation_error_fast_modified(3,:));
xlabel('Time'); ylabel('e_3'); title('e_3 Error - Fast Observer');

sgtitle(figure_errors, 'Estimation Error Analysis: Slow vs. Fast Observers');
saveas(figure_errors, 'Estimation_Error_Comparison.png');


figure_control = figure;
subplot(2, 1, 1);
plot(t_sim_modified, u_slow_modified);
xlabel('Time'); ylabel('u'); title('Control Signal - Slow Observer');
subplot(2, 1, 2);
plot(t_sim_modified, u_fast_modified);
xlabel('Time'); ylabel('u'); title('Control Signal - Fast Observer');

sgtitle(figure_control, 'Control Signal Comparison: Slow vs. Fast Observers');
saveas(figure_control, 'Control_Signal_Comparison.png');

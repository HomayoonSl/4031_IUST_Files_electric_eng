num = [6 18];
den = [1 3 -13.75 -31.5];
T = tf(num, den);
[A, B, C, D] = tf2ss(num, den);
poles_desired = [-5+5i, -5-5i, -10];

A_modified = A;
A_modified(1, 2) = A_modified(1, 2) * 1.2;
sys_modified = ss(A_modified, B, C, D);

Ar_reduced = A_modified(1:2, 1:2);
Br_reduced = B(1:2,:);
Cr_reduced_projected = C(1, 1:2);

observer_poles_reduced_slow = [-12, -7];
observer_poles_reduced_fast = [-30, -20];

L_reduced_slow_naive = place(Ar_reduced', Cr_reduced_projected', observer_poles_reduced_slow')';
L_reduced_fast_naive = place(Ar_reduced', Cr_reduced_projected', observer_poles_reduced_fast')';

T_sim_reduced = 5;
t_sim_reduced = linspace(0, T_sim_reduced, 500);
r_reduced = ones(size(t_sim_reduced));
x0_reduced = [1; -1; 0.5];
x_r_hat0_slow_reduced = [0; 0];
x_r_hat0_fast_reduced = [0; 0];

x_reduced_slow = zeros(3, length(t_sim_reduced));
x_r_hat_slow_reduced = zeros(2, length(t_sim_reduced));
x_hat_slow_reduced_full = zeros(3, length(t_sim_reduced));
y_reduced_slow = zeros(size(C,1), length(t_sim_reduced));
y_measured_slow_reduced = zeros(size(C,1), length(t_sim_reduced));
u_reduced_slow = zeros(size(B,2), length(t_sim_reduced));

x_reduced_slow(:,1) = x0_reduced;
x_r_hat_slow_reduced(:,1) = x_r_hat0_slow_reduced;
y_reduced_slow(:,1) = C*x_reduced_slow(:,1) + D*r_reduced(1);
y_measured_slow_reduced(:,1) = C*x_reduced_slow(:,1) + D*r_reduced(1);
x_hat_slow_reduced_full(:,1) = [x_r_hat_slow_reduced(:,1); 0];

K = place(A,B,poles_desired); % Assuming K is needed but was missing in original code. You might need to define it based on your control design.

for i = 1:length(t_sim_reduced)-1
    dt = t_sim_reduced(i+1) - t_sim_reduced(i);

    x_hat_control_naive = [x_r_hat_slow_reduced(:,i); 0];
    u_reduced_slow(:,i) = -K * x_hat_control_naive; % Assuming K is defined

    x_dot_reduced_slow = A_modified*x_reduced_slow(:,i) + B*u_reduced_slow(:,i);
    x_reduced_slow(:,i+1) = x_reduced_slow(:,i) + x_dot_reduced_slow * dt;
    y_reduced_slow(:,i+1) = C*x_reduced_slow(:,i+1) + D*r_reduced(i+1);
    y_measured_slow_reduced(:,i+1) = C*x_reduced_slow(:,i+1) + D*r_reduced(i+1);

    x_r_hat_dot_slow_reduced = Ar_reduced * x_r_hat_slow_reduced(:,i) + Br_reduced * u_reduced_slow(:,i) + L_reduced_slow_naive*(y_measured_slow_reduced(:,i+1) - Cr_reduced_projected * x_r_hat_slow_reduced(:,i));
    x_r_hat_slow_reduced(:,i+1) = x_r_hat_slow_reduced(:,i) + x_r_hat_dot_slow_reduced * dt;
    x_hat_slow_reduced_full(1:2, i+1) = x_r_hat_slow_reduced(:, i+1);
    x_hat_slow_reduced_full(3, i+1) = 0;
end

x_reduced_fast = zeros(3, length(t_sim_reduced));
x_r_hat_fast_reduced = zeros(2, length(t_sim_reduced));
x_hat_fast_reduced_full = zeros(3, length(t_sim_reduced));
y_reduced_fast = zeros(size(C,1), length(t_sim_reduced));
y_measured_fast_reduced = zeros(size(C,1), length(t_sim_reduced));
u_reduced_fast = zeros(size(B,2), length(t_sim_reduced));

x_reduced_fast(:,1) = x0_reduced;
x_r_hat_fast_reduced(:,1) = x_r_hat0_fast_reduced;
y_reduced_fast(:,1) = C*x_reduced_fast(:,1) + D*r_reduced(1);
y_measured_fast_reduced(:,1) = C*x_reduced_fast(:,1) + D*r_reduced(1);
x_hat_fast_reduced_full(:,1) = [x_r_hat_fast_reduced(:,1); 0];

for i = 1:length(t_sim_reduced)-1
    dt = t_sim_reduced(i+1) - t_sim_reduced(i);

    x_hat_control_naive_fast = [x_r_hat_fast_reduced(:,i); 0];
    u_reduced_fast(:,i) = -K *  x_hat_control_naive_fast; % Assuming K is defined

    x_dot_reduced_fast = A_modified*x_reduced_fast(:,i) + B*u_reduced_fast(:,i);
    x_reduced_fast(:,i+1) = x_reduced_fast(:,i) + x_dot_reduced_fast * dt;
    y_reduced_fast(:,i+1) = C*x_reduced_fast(:,i+1) + D*r_reduced(i+1);
    y_measured_fast_reduced(:,i+1) = C*x_reduced_fast(:,i+1) + D*r_reduced(i+1);

    x_r_hat_dot_fast_reduced = Ar_reduced * x_r_hat_fast_reduced(:,i) + Br_reduced * u_reduced_fast(:,i) + L_reduced_fast_naive*(y_measured_fast_reduced(:,i+1) - Cr_reduced_projected * x_r_hat_fast_reduced(:,i));
    x_r_hat_fast_reduced(:,i+1) = x_r_hat_fast_reduced(:,i) + x_r_hat_dot_fast_reduced * dt;
    x_hat_fast_reduced_full(1:2, i+1) = x_r_hat_fast_reduced(:, i+1);
    x_hat_fast_reduced_full(3, i+1) = 0;
end


estimation_error_reduced_slow_naive = x_reduced_slow - x_hat_slow_reduced_full;
estimation_error_reduced_fast_naive = x_reduced_fast - x_hat_fast_reduced_full;


figure;

subplot(3, 2, 1);
plot(t_sim_reduced, x_reduced_slow(1,:), 'b-', t_sim_reduced, x_hat_slow_reduced_full(1,:), 'r--');
xlabel('Time'); ylabel('x_1, x_1_{hat}'); title('x1 (Slow Observer)'); legend('Actual x_1', 'Est x_1');
subplot(3, 2, 3);
plot(t_sim_reduced, x_reduced_slow(2,:), 'b-', t_sim_reduced, x_hat_slow_reduced_full(2,:), 'r--');
xlabel('Time'); ylabel('x_2, x_2_{hat}'); title('x2 (Slow Observer)'); legend('Actual x_2', 'Est x_2');
subplot(3, 2, 5);
plot(t_sim_reduced, x_reduced_slow(3,:), 'b-', t_sim_reduced, x_hat_slow_reduced_full(3,:), 'r--');
xlabel('Time'); ylabel('x_3, x_3_{hat}'); title('x3 (Slow Observer)'); legend('Actual x_3', 'Est x_3');


subplot(3, 2, 2);
plot(t_sim_reduced, x_reduced_fast(1,:), 'b-', t_sim_reduced, x_hat_fast_reduced_full(1,:), 'r--');
xlabel('Time'); ylabel('x_1, x_1_{hat}'); title('x1 (Fast Observer)'); legend('Actual x_1', 'Est x_1');
subplot(3, 2, 4);
plot(t_sim_reduced, x_reduced_fast(2,:), 'b-', t_sim_reduced, x_hat_fast_reduced_full(2,:), 'r--');
xlabel('Time'); ylabel('x_2, x_2_{hat}'); title('x2 (Fast Observer)'); legend('Actual x_2', 'Est x_2');
subplot(3, 2, 6);
plot(t_sim_reduced, x_reduced_fast(3,:), 'b-', t_sim_reduced, x_hat_fast_reduced_full(3,:), 'r--');
xlabel('Time'); ylabel('x_3, x_3_{hat}'); title('x3 (Fast Observer)'); legend('Actual x_3', 'Est x_3');

% اضافه کردن کپشن و ذخیره فیگور 1
annotation('textbox', [0,0,1,0.03], 'string', 'Figure 1: Comparison of Actual and Estimated States with Slow and Fast Observers', 'HorizontalAlignment', 'center', 'FitBoxToText','on');
saveas(gcf, 'figure1_state_estimation_comparison.png');


figure;

subplot(3, 2, 1);
plot(t_sim_reduced, estimation_error_reduced_slow_naive(1,:));
xlabel('Time'); ylabel('e_1'); title('Error e1 (Slow)');
subplot(3, 2, 3);
plot(t_sim_reduced, estimation_error_reduced_slow_naive(2,:));
xlabel('Time'); ylabel('e_2'); title('Error e2 (Slow)');
subplot(3, 2, 5);
plot(t_sim_reduced, estimation_error_reduced_slow_naive(3,:));
xlabel('Time'); ylabel('e_3'); title('Error e3 (Slow)');

subplot(3, 2, 2);
plot(t_sim_reduced, estimation_error_reduced_fast_naive(1,:));
xlabel('Time'); ylabel('e_1'); title('Error e1 (Fast)');
subplot(3, 2, 4);
plot(t_sim_reduced, estimation_error_reduced_fast_naive(2,:));
xlabel('Time'); ylabel('e_2'); title('Error e2 (Fast)');
subplot(3, 2, 6);
plot(t_sim_reduced, estimation_error_reduced_fast_naive(3,:));
xlabel('Time'); ylabel('e_3'); title('Error e3 (Fast)');

% اضافه کردن کپشن و ذخیره فیگور 2
annotation('textbox', [0,0,1,0.03], 'string', 'Figure 2: Estimation Errors for Slow and Fast Observers', 'HorizontalAlignment', 'center', 'FitBoxToText','on');
saveas(gcf, 'figure2_estimation_errors.png');


figure;
subplot(2, 1, 1);
plot(t_sim_reduced, u_reduced_slow);
xlabel('Time'); ylabel('u'); title('Control (Slow)');
subplot(2, 1, 2);
plot(t_sim_reduced, u_reduced_fast);
xlabel('Time'); ylabel('u (Fast)'); title('Control (Fast)');


% اضافه کردن کپشن و ذخیره فیگور 3
annotation('textbox', [0,0,1,0.03], 'string', 'Figure 3: Control Signals for Slow and Fast Observers', 'HorizontalAlignment', 'center', 'FitBoxToText','on');
saveas(gcf, 'figure3_control_signals.png');


disp('Dimensions of Naive Reduced Observer:');
disp(['Ar_reduced: ', num2str(size(Ar_reduced))]);
disp(['Br_reduced: ', num2str(size(Br_reduced))]);
disp(['Cr_reduced_projected: ', num2str(size(Cr_reduced_projected))]);
disp(['L_reduced_slow_naive: ', num2str(size(L_reduced_slow_naive))]);
disp(['L_reduced_fast_naive: ', num2str(size(L_reduced_fast_naive))]);

num_fb = [6 18];
den_fb = [1 3 -13.75 -31.5];
T_fb = tf(num_fb, den_fb);
[A_fb, B_fb, C_fb, D_fb] = tf2ss(num_fb, den_fb);
sys_fb = ss(A_fb, B_fb, C_fb, D_fb);

poles_fast = [-25, -15+15i, -15-15i];
K_fast_fb = place(A_fb, B_fb, poles_fast);
sys_fast_cl = ss(A_fb-B_fb*K_fast_fb,B_fb, C_fb,D_fb)   ;

poles_slow = [-7, -4+4i, -4-4i];
K_slow_fb = place(A_fb, B_fb, poles_slow);
sys_slow_cl = ss(A_fb -B_fb*K_slow_fb,B_fb, C_fb,D_fb);

t_sim_fb = linspace(0, 5, 500);
x0_fb = [1; -1; 0.5];
x_fast = zeros(3, length(t_sim_fb));
x_slow = zeros(3, length(t_sim_fb));
u_fast = zeros(size(B_fb, 2), length(t_sim_fb));
u_slow = zeros(size(B_fb, 2), length(t_sim_fb));
x_fast(:, 1) = x0_fb;
x_slow(:,1)= x0_fb;

for i=1:length(t_sim_fb)-1
    dt = t_sim_fb(i+1) - t_sim_fb(i);

      u_fast(:, i) = -K_fast_fb*x_fast(:, i);
      x_dot_fast = A_fb*x_fast(:, i) + B_fb*u_fast(:, i) ;
     x_fast(:, i+1) =  x_fast(:, i)  + x_dot_fast*dt ;

     u_slow(:, i) = -K_slow_fb*x_slow(:, i);
       x_dot_slow = A_fb*x_slow(:, i)+ B_fb*u_slow(:, i);
    x_slow(:, i+1) = x_slow(:, i) +  x_dot_slow*dt;
end

fig1 = figure; % Get figure handle
subplot(3, 2, 1);
plot(t_sim_fb, x_fast(1,:));
xlabel('Time'); ylabel('x_1'); title('State x_1 - Fast Poles');
subplot(3, 2, 3);
plot(t_sim_fb, x_fast(2,:));
xlabel('Time'); ylabel('x_2'); title('State x_2 - Fast Poles')
subplot(3, 2, 5);
plot(t_sim_fb, x_fast(3,:));
xlabel('Time'); ylabel('x_3'); title('State x_3 - Fast Poles');

subplot(3, 2, 2);
plot(t_sim_fb, x_slow(1,:));
xlabel('Time'); ylabel('x_1'); title('State x_1 - Slow Poles');
subplot(3, 2, 4);
plot(t_sim_fb, x_slow(2,:));
xlabel('Time'); ylabel('x_2'); title('State x_2 - Slow Poles');
subplot(3, 2, 6);
plot(t_sim_fb, x_slow(3,:));
xlabel('Time'); ylabel('x_3'); title('State x_3 - Slow Poles');

% Save figure 1 with caption
caption1 = 'State Response Comparison - Fast and Slow Pole Placement';
annotation('textbox', [0, 0.95, 1, 0.05], 'String', caption1, 'HorizontalAlignment', 'center', 'FontSize', 12, 'FontWeight', 'bold', 'LineStyle', 'none');
saveas(fig1, 'State_Response_Fast_Slow_Poles.png');


fig2 = figure; % Get figure handle
subplot(2, 1, 1);
plot(t_sim_fb, u_fast);
xlabel('Time'); ylabel('Control signal (u)');  title('Control Input u - Fast Poles');
subplot(2, 1, 2);
plot(t_sim_fb, u_slow);
xlabel('Time'); ylabel('Control Signal (u)');   title('Control Input u - Slow Poles');

% Save figure 2 with caption
caption2 = 'Control Input Comparison - Fast and Slow Pole Placement';
annotation('textbox', [0, 0.95, 1, 0.05], 'String', caption2, 'HorizontalAlignment', 'center', 'FontSize', 12, 'FontWeight', 'bold', 'LineStyle', 'none');
saveas(fig2, 'Control_Input_Fast_Slow_Poles.png');


disp('State Feedback Control - Fast/Slow Poles');
disp('State graphs from TF model. Control parameters for specific designs.');
disp('Observer effects not used.');
disp('Controllers designed with pole placement.');
disp('Control efforts (u) and state profiles show design impact.');
disp('Simulation tests controller parameter effects (fast vs slow convergence).');
disp('Compare settling speeds and oscillations.');
disp('Differences via fast/slow parameters.');
disp('Controller influence highlighted by response changes.');

num_fast = [6 18];
den_fast = [1 3 -13.75 -31.5];
T_fast = tf(num_fast, den_fast);
[A_fast, B_fast, C_fast, D_fast] = tf2ss(num_fast, den_fast);
sys_fast_ss = ss(A_fast,B_fast, C_fast, D_fast);

poles_fast = [-25, -15+15i, -15-15i];
K_fast_tracker = place(A_fast, B_fast, poles_fast);

Nbar_tracker_fast = (C_fast*inv(A_fast - B_fast*K_fast_tracker)*B_fast)^-1;

ki =1  ;
t_tracker = linspace(0, 1, 500);
r_tracker= ones(size(t_tracker));
x0_tracker = [1; -1; 0.5];

x_fast_tracker= zeros(3, length(t_tracker));
u_static_track_fb= zeros(size(B_fast, 2), length(t_tracker));
x_integrator_fast_tracker= zeros(size(B_fast, 2), length(t_tracker))   ;
y_tracker=zeros(size(C_fast, 1),length(t_tracker));

x_integrator = 0  ;

x_fast_tracker(:, 1) = x0_tracker;

for i = 1:length(t_tracker) - 1

  dt = t_tracker(i + 1) - t_tracker(i);

     u_static_track_fb(:,i)  = -K_fast_tracker * x_fast_tracker(:,i)+  Nbar_tracker_fast *r_tracker(i)  ;

      x_dot_fast_track_design  =   A_fast * x_fast_tracker(:,i)+ B_fast * u_static_track_fb(:,i)   ;
       x_fast_tracker(:, i+1) =    x_fast_tracker(:, i)  +  x_dot_fast_track_design *dt;

     y_tracker(:, i + 1)  =   C_fast * x_fast_tracker(:, i+1)  + D_fast * r_tracker(i+1)   ;


      error =  r_tracker(i)  - C_fast * x_fast_tracker(:,i) ;
  x_integrator_dot   =  error ;
      x_integrator     = x_integrator+    x_integrator_dot * dt;
   u_integrator_fast = -K_fast_tracker* x_fast_tracker(:,i)+  ki * x_integrator  ;
       x_dot_integrator   =    A_fast * x_fast_tracker(:,i) +  B_fast *u_integrator_fast ;
 x_fast_tracker(:, i+1)  =   x_fast_tracker(:, i)  + x_dot_integrator* dt   ;


end


figure;

subplot(3, 2, 1);
plot(t_tracker, x_fast_tracker(1,:));
xlabel('Time'); ylabel('x_1'); title('State x1 (Static Feedforward)');
subplot(3, 2, 3);
plot(t_tracker, x_fast_tracker(2,:));
xlabel('Time'); ylabel('x_2'); title('State x2 (Static Feedforward)');
subplot(3, 2, 5);
plot(t_tracker, x_fast_tracker(3,:));
xlabel('Time'); ylabel('x_3'); title('State x3 (Static Feedforward)');


subplot(3, 2, 2);
plot(t_tracker, u_static_track_fb);
xlabel('Time'); ylabel('Control Input u'); title('Control u (Static Tracking)');


subplot(3, 2, 4);
plot(t_tracker,  y_tracker) ;
xlabel('Time'); ylabel('Output y');
  title('Output (Static Compensator)');

caption1 = 'Static Feedforward Controller Performance';
filename1 = 'static_feedforward_performance';
saveas(gcf, filename1, 'png');


figure;

subplot(3, 2, 1);
plot(t_tracker, x_fast_tracker(1,:));
xlabel('Time'); ylabel('x_1'); title('State x1 (Integral Control)');
subplot(3, 2, 3);
plot(t_tracker, x_fast_tracker(2,:));
xlabel('Time'); ylabel('x_2'); title('State x2 (Integral Control)');
subplot(3, 2, 5);
plot(t_tracker, x_fast_tracker(3,:));
xlabel('Time'); ylabel('x_3'); title('State x3 (Integral Control)');

subplot(3, 2, 2);
plot(t_tracker,   u_integrator_fast );
xlabel('Time'); ylabel('Control Output u');
title('Control output (Integrator)');
subplot(3, 2, 4);
plot(t_tracker,y_tracker );
xlabel('Time'); ylabel('Output y');   title('System Output (Integral Feedback)');

caption2 = 'Integral Controller Performance';
filename2 = 'integral_controller_performance';
saveas(gcf, filename2, 'png');
